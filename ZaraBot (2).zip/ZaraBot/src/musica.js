/* =================================================
   🎵 ZARA BOT — SISTEMA DE DOWNLOAD V6 (RÁPIDO)
   📁 Arquivo: musica.js
   👑 DOCTOR VALEYARD

   Antes: buscava (1 processo), mandava um card com "escolha 1-4",
   esperava a pessoa responder (até 40s!), só DEPOIS baixava (2º processo).
   Isso é o que fazia o comando demorar mais de um minuto.

   Agora: um comando só já busca E baixa em UM ÚNICO processo do yt-dlp
   (usando --print-json, que baixa e já devolve os metadados juntos).
   Sem menu, sem espera de resposta — manda o comando, já vem a música.

   Uso:
     .play nome da música        -> baixa em ÁUDIO (padrão, mais rápido)
     .play video nome da música  -> baixa em VÍDEO
================================================= */

const { exec } = require('child_process');
const fs   = require('fs');
const path = require('path');
const https = require('https');
const config = require('../config');
const { criarCardMusica } = require('./cardGenerator');
const { buscarFotoContexto } = require('./foto-contexto');
const { gerarMensagemMusica } = require('./musica-mensagens');

// 🎵 Monta o "prefixo" do comando yt-dlp a partir da config — trocar de
// binário/provedor é só mexer em config.MUSICA, sem tocar no resto do código.
function comandoBase() {
    const extra = config.MUSICA?.ARGS_EXTRA ? ` ${config.MUSICA.ARGS_EXTRA}` : "";
    return `${config.MUSICA?.BINARIO || "yt-dlp"}${extra}`;
}

// ── HELPERS ──────────────────────────────────────

function escapeShellArg(arg) {
    return `'${arg.replace(/'/g, "'\\''")}'`;
}

function formatDuration(s) {
    if (isNaN(s) || s < 0) return "00:00";
    const m = Math.floor(s / 60);
    const r = Math.floor(s % 60);
    return `${String(m).padStart(2,'0')}:${String(r).padStart(2,'0')}`;
}

function baixarImagem(url) {
    return new Promise((resolve, reject) => {
        https.get(url, res => {
            if (res.statusCode !== 200) return reject(new Error('sem imagem'));
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end',  () => resolve(Buffer.concat(chunks)));
        }).on('error', reject);
    });
}

// ── CONTROLE DE ESPERA (mantido só por compatibilidade com quem importa) ──
let aguardandoReferencia = null;
exports.setReferenciaEspera = (ref) => { aguardandoReferencia = ref; };

// ── COMANDO PRINCIPAL ─────────────────────────────

exports.baixarMusica = async function(sock, msg, args) {
    const from      = msg.key.remoteJid;
    const remetente = msg.key.participant || msg.key.remoteJid;
    const nomeSolicitante = msg.pushName || remetente.split('@')[0];

    // 🎬 ".play mp4 nome" -> vídeo | ".play doc nome" -> documento
    // Sem nada na frente, o padrão é ÁUDIO (o caso mais comum e mais rápido).
    let modo = "audio";
    let argsBusca = [...args];
    const primeiraPalavra = (argsBusca[0] || "").toLowerCase();
    if (["mp4", "video", "vídeo"].includes(primeiraPalavra)) {
        modo = "video";
        argsBusca.shift();
    } else if (["doc", "documento"].includes(primeiraPalavra)) {
        modo = "doc";
        argsBusca.shift();
    }
    const busca = argsBusca.join(" ").trim();

    if (!busca || busca.length < 2) {
        return sock.sendMessage(from, {
            text:
`┅┄┅┄『 ✦ 』┄┅┄┅┄
 ❌ *ERRO — SEM BUSCA*
┅┄┅┄『 ✦ 』┄┅┄┅┄
💡 Use: *${config.PREFIX}play nome da música* (áudio)
*${config.PREFIX}play mp4 nome* (vídeo)
*${config.PREFIX}play doc nome* (documento)
┅┄┅┄『 ✦ 』┄┅┄┅┄`
        }, { quoted: msg });
    }

    const id       = Date.now();
    const template = path.join(__dirname, `${id}`);
    const searchArg = escapeShellArg(busca);

    let aviso;
    try {
        aviso = await sock.sendMessage(from, {
            text: `🔍 Buscando e baixando *${busca}*... só um instante! ⏳`
        }, { quoted: msg });
    } catch { aviso = msg; }

    try {
        // ── BUSCA + DOWNLOAD EM UM ÚNICO PROCESSO ──
        // --print-json baixa E devolve os metadados no mesmo comando —
        // antes eram 2 processos (1 só pra info, outro só pro download).
        //
        // 🚀 GRANDE GANHO DE VELOCIDADE: pro modo áudio, antes o yt-dlp
        // baixava E DEPOIS re-codificava pra MP3 (-x --audio-format mp3)
        // — essa conversão usa bastante processador e é isso que mais
        // pesava num celular rodando pelo Termux. Agora baixa o áudio no
        // formato ORIGINAL (m4a/webm), sem recodificar nada — o WhatsApp
        // toca m4a/opus numa boa, então não perde nada, só ganha tempo.
        // ⚡ --concurrent-fragments 4 baixa vários pedaços do vídeo/áudio em
        // paralelo (em vez de 1 por vez), o que ajuda a velocidade sem mexer
        // no jeito que o YouTube é consultado.
        // (nota: chegamos a testar forçar o "player_client=android" pra
        // acelerar a extração, mas o YouTube anda bloqueando esse client com
        // frequência — causava demora, timeout e arquivo quebrado. Removido.)
        const flagsVelocidade = `--concurrent-fragments 4 --no-warnings`;

        const comando = modo === "video" || modo === "doc"
            ? `${comandoBase()} "ytsearch1:${searchArg}" -f "best[ext=mp4]/best" --no-playlist ${flagsVelocidade} -o "${template}.%(ext)s" --print-json`
            : `${comandoBase()} "ytsearch1:${searchArg}" -f "bestaudio[ext=m4a]/bestaudio/best" --no-playlist ${flagsVelocidade} -o "${template}.%(ext)s" --print-json`;

        const rawJson = await new Promise((res, rej) => {
            exec(comando, { maxBuffer: 1024 * 1024 * 20 }, (err, stdout) => {
                if (err || !stdout) return rej(new Error('Nada encontrado. Tente outro termo.'));
                res(stdout);
            });
        });

        // --print-json pode devolver mais de uma linha em alguns casos —
        // pega só a última (que é o resultado final já processado).
        const linhasJson = rawJson.trim().split("\n").filter(Boolean);
        const info = JSON.parse(linhasJson[linhasJson.length - 1]);
        const { title, duration, uploader, thumbnail } = info;

        // ── Acha o arquivo baixado (qualquer extensão) ──
        const exts = (modo === "video" || modo === "doc") ? ['.mp4','.mkv','.webm'] : ['.m4a','.webm','.opus','.mp3'];
        let arquivoReal = null;
        for (const ext of exts) {
            const candidato = `${template}${ext}`;
            if (fs.existsSync(candidato)) { arquivoReal = candidato; break; }
        }
        if (!arquivoReal || fs.statSync(arquivoReal).size < 5000) {
            throw new Error('Arquivo não gerado ou muito pequeno.');
        }

        const buffer = fs.readFileSync(arquivoReal);
        const extensaoBaixada = path.extname(arquivoReal); // extensão real do que foi baixado
        const extensaoFinal = (modo === "video" || modo === "doc") ? '.mp4' : extensaoBaixada;
        const nomeArquivo = `${(title || "musica").replace(/[<>:"/\\|?*]/g,'')}${extensaoFinal}`;
        const mimetypeAudio = extensaoBaixada === '.webm' ? 'audio/webm'
                              : extensaoBaixada === '.opus' ? 'audio/ogg; codecs=opus'
                              : extensaoBaixada === '.mp3' ? 'audio/mpeg'
                              : 'audio/mp4'; // m4a

        // ── Envia a mídia ──────────────────────────
        if (modo === "video") {
            await sock.sendMessage(from, { video: buffer, mimetype: 'video/mp4', fileName: nomeArquivo }, { quoted: aviso });
        } else if (modo === "doc") {
            await sock.sendMessage(from, { document: buffer, mimetype: 'video/mp4', fileName: nomeArquivo }, { quoted: aviso });
        } else {
            await sock.sendMessage(from, { audio: buffer, mimetype: mimetypeAudio, ptt: false, fileName: nomeArquivo }, { quoted: aviso });
        }

        // 🗑️ Apaga o arquivo do disco assim que envia (não fica salvo à toa)
        try { fs.unlinkSync(arquivoReal); } catch {}

        // ── Card final (foto de quem pediu + capa da música) + mensagem aleatória ──
        let capaBuffer = null, fotoContextoBuffer = null;
        try { capaBuffer = await baixarImagem(thumbnail); } catch {}
        try { fotoContextoBuffer = await buscarFotoContexto(sock, from); } catch {}

        const mensagemAleatoria = gerarMensagemMusica(nomeSolicitante, title || busca);
        try {
            const card = await criarCardMusica({
                capaBuffer,
                titulo: title || busca,
                artista: uploader || "—",
                duracao: formatDuration(duration),
                fotoContextoBuffer,
                nomeSolicitante
            });
            await sock.sendMessage(from, { image: card, caption: mensagemAleatoria, mentions: [remetente] });
        } catch (erroCard) {
            console.error("❌ Erro ao gerar card final da música:", erroCard);
            await sock.sendMessage(from, { text: mensagemAleatoria, mentions: [remetente] });
        }

    } catch (err) {
        console.error("❌ MUSICA ERRO:", err.message);

        try {
            const exts = ['.mp3','.mp4','.mkv','.webm','.m4a','.opus'];
            exts.forEach(e => {
                const f = `${template}${e}`;
                if (fs.existsSync(f)) fs.unlinkSync(f);
            });
        } catch {}

        try {
            await sock.sendMessage(from, {
                text:
`┅┄┅┄『 ✦ 』┄┅┄┅┄
❌ *ERRO NO DOWNLOAD*
┅┄┅┄『 ✦ 』┄┅┄┅┄
💬 ${err.message}
┅┄┅┄『 ✦ 』┄┅┄┅┄
Tente novamente ou use outro termo.
┅┄┅┄『 ✦ 』┄┅┄┅┄`
            }, { quoted: msg });
        } catch {}
    }
};
