// ==================================================
// 👑 CRÉDITO DO CRIADOR — mensagem que vem ANTES do menu
// 📁 Arquivo: src/menu-credito.js
//
// Sempre que alguém pede o menu (com prefixo ou sem prefixo), o bot
// primeiro manda esta mensagenzinha com o nome do criador e só depois
// manda o menu em si.
//
// Pra trocar o texto: edite MENU_CREDITO no config.js (ou salve
// MENU_CREDITO no database/botconfig.json).
// ==================================================

const config = require("../config");

const CREDITO_PADRAO = "꧁ঔৣ BY:  DOCTOR VALEYARDঔৣ꧂";

function textoCredito() {
    const personalizado = config.MENU_CREDITO;
    return typeof personalizado === "string" && personalizado.trim()
        ? personalizado
        : CREDITO_PADRAO;
}

// A mensagem sai como um BOTÃO AZUL (native flow) com o nome do criador.
// Tocar nele abre as informações do criador (.dono). Se o botão não puder
// ser enviado, cai pra mensagem de texto comum — o menu nunca fica sem crédito.
// Se falhar por qualquer motivo, NÃO derruba o menu: só segue em frente.
async function enviarCredito(sock, jid) {
    const texto = textoCredito();
    try {
        const { enviarNativeFlow, botao } = require("./menuBotoes");
        await enviarNativeFlow(sock, jid, {
            text: "👑 *CRIADOR DO BOT*",
            footer: config.BOT_NAME || "Zara Bot",
            buttons: [botao(texto, "dono_info")],
        });
        return true;
    } catch (erroBotao) {
        console.error("⚠️ Crédito em botão falhou, mandando em texto:", erroBotao?.message || erroBotao);
    }
    try {
        await sock.sendMessage(jid, { text: texto });
        return true;
    } catch (erro) {
        console.error("⚠️ Não consegui enviar o crédito do criador:", erro?.message || erro);
        return false;
    }
}

module.exports = { enviarCredito, textoCredito, CREDITO_PADRAO };
