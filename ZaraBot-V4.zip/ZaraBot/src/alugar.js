const config = require("../config");

async function alugar(sock, msg) {
    const from = msg.key.remoteJid;
    
    const resp = `💼 *ALUGAR ${config.BOT_NAME}*\n\nInteressado em alugar este bot?\n\n📞 Contato: ${config.OWNER_NUMBER}\n👑 Criadora: ${config.OWNER_NAME}\n\nEntre em contato para mais informações!`;
    await sock.sendMessage(from, { text: resp }, { quoted: msg });
}

module.exports = { alugar };
