const config = require("../config");
async function resumo(sock, msg) {
    const from = msg.key.remoteJid;
    const isGroup = msg.key.remoteJid.endsWith("@g.us");
    
    if (!isGroup) return sock.sendMessage(from, { text: `❌ Só em grupos!` }, { quoted: msg });
    
    try {
        const groupMetadata = await sock.groupMetadata(from);
        const resp = `
╭─「 📊 *RESUMO DO GRUPO* 」
│
│ 📛 Nome: ${groupMetadata.subject}
│ 👥 Membros: ${groupMetadata.participants.length}
│ 👮 Admins: ${groupMetadata.participants.filter(p => p.admin).length}
│ 📅 Criado: ${new Date(groupMetadata.creation * 1000).toLocaleDateString("pt-BR")}
│
│ 🔔 Descição: ${groupMetadata.desc || "Sem descrição"}
╰───────────────────────────`;
        await sock.sendMessage(from, { text: resp }, { quoted: msg });
    } catch (err) {
        await sock.sendMessage(from, { text: `❌ Erro: ${err.message}` }, { quoted: msg });
    }
}
module.exports = { resumo };
