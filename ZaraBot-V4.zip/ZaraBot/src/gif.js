/* =================================================
   🎬 CONVERSOR UNIVERSAL — TUDO PARA GIF / VÍDEO
   📁 Arquivo: converterParaGif.js
   🤖 ${config.BOT_NAME} • ${config.OWNER_NAME}
   💡 FUNCIONA COM: IMAGEM • VÍDEO • FIGURINHA (ESTÁTICA OU ANIMADA)
   ================================================= */

const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
const { exec } = require("child_process");
const fs = require("fs");
const path = require("path");
const config = require("../config");

// 💬 FRASES — MESMA PERSONALIDADE QUE VOCÊ QUERIA 😏
const frasesProcesso = [
    "Vou converter isso logo antes que eu desista de você... 🙄",
    "Paciência viu, cada arquivo que me mandam... 🤦‍♂️",
    "Segura a ansiedade aí, não sou flash não! ⚡",
    "Tô fazendo o meu melhor, mas com essa sua internet... 🐢",
    "Pronto, vou colocar pra rodar, vê se não vicia! 😏",
    "Você não tem nada melhor pra fazer não? Mas tá bom, vou converter... 🥱",
    "Olha só, o mestre das conversões atacando novamente... 🤡",
    "Vou te dar esse resultado só porque hoje eu tô de bom humor... ✨",
    "Trabalhando duro enquanto você só manda coisa, né? 🛠️",
    "Espero que esse resultado seja melhor que suas piadas... 🎤",
    "Vou processar aqui, tenta não quebrar meu sistema com essa beleza... 💅",
    "Mais um arquivo pra sua coleção? Calma que já sai! 📦"
];

const frasesEntrega = [
    "Aí está! Agora pode usar como quiser... 😎",
    "Pronto e entregue, feito com toda a minha paciência... que não é pouca 🤣.",
    "Toma aí! Não vem dizer que demorei, hein.",
    "Obra-prima finalizada! Agradece que eu sou útil.",
    "Quando eu faço, não tem erro. Confia!",
    "Resultado na mão! E ainda de brinde: meu bom humor.",
    "Aqui está, cheiroso e novinho em folha.",
    `Feito sob medida com tecnologia ${config.BOT_NAME}! ⚡`
];

const pegarFraseProcesso = () => frasesProcesso[Math.floor(Math.random() * frasesProcesso.length)];
const pegarFraseEntrega = () => frasesEntrega[Math.floor(Math.random() * frasesEntrega.length)];

// 🧹 LIMPEZA TOTAL — NÃO DEIXA NADA SOBRANDO
function limparArquivos(caminhoEntrada, caminhoSaida, pastaQuadros = null) {
    try {
        if (fs.existsSync(caminhoEntrada)) fs.unlinkSync(caminhoEntrada);
        if (fs.existsSync(caminhoSaida)) fs.unlinkSync(caminhoSaida);
        if (pastaQuadros && fs.existsSync(pastaQuadros)) fs.rmSync(pastaQuadros, { recursive: true, force: true });
    } catch {}
}

// 📤 ENVIO FINAL PADRÃO
async function enviarResultado(sock, dados) {
    const { from, remetente, arquivoFinal, msg } = dados;

    try {
        const mensagemFinal = `
〔 🎬 𝐂𝐎𝐍𝐕𝐄𝐑𝐒𝐀̃𝐎 𝐅𝐈𝐍𝐀𝐋𝐈𝐙𝐀𝐃𝐀 
『 ✅ 𝐄𝐍𝐓𝐑𝐄𝐆𝐀 𝐂𝐎𝐍𝐂𝐋𝐔𝐈́𝐃𝐀 』
 └─ @${remetente.split('@')[0]}
 └─ "${pegarFraseEntrega()}"
━━━━━━━━━━━━━━
«🎞️ 𝐅𝐎𝐑𝐌𝐀𝐓𝐎
└─ Vídeo / GIF Animado
━━━━━━━━━━━━━━
🤍 ${config.BOT_NAME}
🌹 ${config.OWNER_NAME}
━━━━━━━━━━━━━━»
        `;

        await sock.sendMessage(from, { 
            video: fs.readFileSync(arquivoFinal), 
            mimetype: 'video/mp4',
            caption: mensagemFinal,
            mentions: [remetente],
            gifPlayback: true // ✅ Aparece direto como GIF no WhatsApp
        }, { quoted: msg });

    } catch (erroEnvio) {
        console.error("❌ Erro envio:", erroEnvio);
        await sock.sendMessage(from, { text: "⚠️ Converti certo, mas deu problema ao enviar! Tente novamente." }, { quoted: msg });
    } finally {
        limparArquivos(dados.tempEntrada, arquivoFinal, dados.pastaQuadros);
    }
}

// ⚙️ FUNÇÃO PRINCIPAL — ACEITA TUDO E SE ADAPTA SOZINHA
async function converterParaGif(sock, msg) {
    const from = msg.key.remoteJid;
    const remetente = msg.key.participant || msg.key.remoteJid;

    // 📥 PEGA QUALQUER TIPO DE MÍDIA — DIRETA OU RESPONDIDA
    const dir = msg.message;
    const res = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

    let midia, tipo;

    if (res?.stickerMessage) { midia = res.stickerMessage; tipo = res.stickerMessage.isAnimated ? "sticker_animado" : "sticker_estatico"; }
    else if (dir?.stickerMessage) { midia = dir.stickerMessage; tipo = dir.stickerMessage.isAnimated ? "sticker_animado" : "sticker_estatico"; }
    else if (res?.imageMessage) { midia = res.imageMessage; tipo = "imagem"; }
    else if (dir?.imageMessage) { midia = dir.imageMessage; tipo = "imagem"; }
    else if (res?.videoMessage) { midia = res.videoMessage; tipo = "video"; }
    else if (dir?.videoMessage) { midia = dir.videoMessage; tipo = "video"; }
    else {
        // ❌ NÃO TEM NENHUMA MÍDIA
        return sock.sendMessage(from, { 
            text: `❌ *NÃO ENCONTREI NADA!*\n\nEnvie ou RESPONDA em cima de:\n🖼️ Imagem | 🎥 Vídeo | 🎴 Figurinha\nCom: ${config.PREFIX}f / ${config.PREFIX}gif` 
        }, { quoted: msg });
    }

    try {
        // ✅ AVISO INICIAL
        const avisoInicio = `
〔 ⏳ 𝐏𝐑𝐎𝐂𝐄𝐒𝐒𝐀𝐍𝐃𝐎 𝐀𝐑𝐐𝐔𝐈𝐕𝐎 〕
『 ⚙️ 𝐏𝐑𝐎𝐂𝐄𝐒𝐒𝐎 𝐄𝐌 𝐀𝐍𝐃𝐀𝐌𝐄𝐍𝐓𝐎 』
└─ @${remetente.split('@')[0]}
└─ "${pegarFraseProcesso()}"
━━━━━━━━━━━━━━
«⏳ 𝐀𝐆𝐔𝐀𝐑𝐃𝐄...
└─ Aguarda que já vai ficar pronto! 🤭
━━━━━━━━━━━━━━
🤍 ${config.BOT_NAME}
🌹 ${config.OWNER_NAME}
━━━━━━━━━━━━━━»        
        `;

        await sock.sendMessage(from, { text: avisoInicio, mentions: [remetente] }, { quoted: msg });

        // ⬇️ BAIXA O ARQUIVO
        const stream = await downloadContentFromMessage(midia, tipo.includes("sticker") ? "sticker" : tipo);
        let buffer = Buffer.from([]);
        for await (const pedaco of stream) buffer = Buffer.concat([buffer, pedaco]);

        // 📁 ARQUIVOS ÚNICOS
        const idUnico = Date.now() + "_" + Math.floor(Math.random() * 9999);
        const tempEntrada = path.join(__dirname, `ent_${idUnico}.tmp`);
        const tempSaida = path.join(__dirname, `sai_${idUnico}.mp4`);
        const pastaQuadros = path.join(__dirname, `quadros_${idUnico}`);

        fs.writeFileSync(tempEntrada, buffer);

        // 🎯 AQUI DECIDE O CAMINHO CERTO DE CONVERSÃO
        // ⚡ preset veryfast (era "medium") = codifica bem mais rápido com o
        // mesmo CRF, ou seja, mesma qualidade visual, arquivo levemente maior
        // — ótima troca pra quem tá rodando isso num celular via Termux.
        // -threads 0 deixa o ffmpeg usar todos os núcleos disponíveis.
        if (tipo === "sticker_animado") {
            // 🎴 ANIMADA → o ffmpeg já decodifica webp animado direto, sem
            // precisar mais passar pelo ImageMagick extraindo quadro por
            // quadro em disco (esse passo extra era o que mais pesava aqui).
            const cmd = `ffmpeg -y -threads 0 -i "${tempEntrada}" -c:v libx264 -pix_fmt yuv420p -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2,fps=20" -crf 20 -preset veryfast -an "${tempSaida}"`;

            exec(cmd, (erroFfmpeg) => {
                if (erroFfmpeg) {
                    console.error("❌ Erro ao converter sticker animado:", erroFfmpeg.message);
                    limparArquivos(tempEntrada, tempSaida, pastaQuadros);
                    return sock.sendMessage(from, { text: "⚠️ Não consegui converter essa figurinha animada. Tente novamente." }, { quoted: msg });
                }
                enviarResultado(sock, { from, remetente, tempEntrada, arquivoFinal: tempSaida, pastaQuadros: null, msg });
            });
        } 
        else if (tipo === "sticker_estatico" || tipo === "imagem") {
            // 🖼️ ESTÁTICA/IMAGEM → CRIA VÍDEO COM DURAÇÃO PARA FICAR COMO GIF
            const cmd = `ffmpeg -y -threads 0 -loop 1 -i "${tempEntrada}" -t 3 -c:v libx264 -pix_fmt yuv420p -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2,fps=20" -crf 20 -preset veryfast -an "${tempSaida}"`;
            
            exec(cmd, () => enviarResultado(sock, { from, remetente, tempEntrada, arquivoFinal: tempSaida, pastaQuadros: null, msg }));
        } 
        else {
            // 🎥 VÍDEO → OTIMIZA E ENVIA DIRETO COMO GIF
            const cmd = `ffmpeg -y -threads 0 -i "${tempEntrada}" -t 3 -c:v libx264 -pix_fmt yuv420p -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2,fps=20" -crf 20 -preset veryfast -an "${tempSaida}"`;
            
            exec(cmd, () => enviarResultado(sock, { from, remetente, tempEntrada, arquivoFinal: tempSaida, pastaQuadros: null, msg }));
        }

    } catch (erroGeral) {
        console.error("Erro:", erroGeral);
        await sock.sendMessage(from, { text: "😵 Erro inesperado ao processar arquivo!" }, { quoted: msg });
    }
}

module.exports = { converterParaGif };

