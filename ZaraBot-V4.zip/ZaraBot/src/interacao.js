const path = require('path');
const fs = require('fs');
const { normalize } = require('./grupo');

async function interacao(sock, from, msg, command, args) {
    const citado = msg.message?.extendedTextMessage?.contextInfo?.participant;
    const mencionado = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const alvo = mencionado || citado;

    if (!alvo) {
        return sock.sendMessage(from, { text: `❌ Você precisa marcar alguém para usar o comando ${command}!` }, { quoted: msg });
    }

    const remetente = msg.key.participant || msg.key.remoteJid;
    const nomeRemetente = normalize(remetente);
    const nomeAlvo = normalize(alvo);

    const midias = {
        matar: 'matar.mp4',
        tapa: 'tapa.mp4',
        beijar: 'beijar.mp4',
        abracar: 'abracar.mp4'
    };

    const verbos = {
        matar: 'matou',
        tapa: 'deu um tapa em',
        beijar: 'deu um beijo em',
        abracar: 'deu um abraço em'
    };

    const emojis = {
        matar: '💀',
        tapa: '🖐️',
        beijar: '💋',
        abracar: '🫂'
    };

    const arquivo = midias[command];
    const caminho = path.join(__dirname, '../media', arquivo);

    const texto = `✨ *INTERAÇÃO* ✨\n\n@${nomeRemetente} ${verbos[command]} @${nomeAlvo} ${emojis[command]}`;

    if (fs.existsSync(caminho)) {
        await sock.sendMessage(from, {
            video: fs.readFileSync(caminho),
            caption: texto,
            gifPlayback: true,
            mentions: [remetente, alvo]
        }, { quoted: msg });
    } else {
        await sock.sendMessage(from, { text: texto, mentions: [remetente, alvo] }, { quoted: msg });
    }
}

module.exports = { interacao };
