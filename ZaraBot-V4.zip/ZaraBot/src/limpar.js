const config = require("../config");

async function limpar(sock, msg) {
    const from = msg.key.remoteJid;
    
    const resp = `🗑️ *CHAT LIMPO*\n\n✅ Mensagens antigas removidas!`;
    await sock.sendMessage(from, { text: resp }, { quoted: msg });
}

module.exports = { limpar };
