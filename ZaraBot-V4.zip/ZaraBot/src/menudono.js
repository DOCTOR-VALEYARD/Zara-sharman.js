// src/menudono.js
const config = require("../config");
const fs = require("fs");
const path = require("path");

async function menudono(sock, msg) {
    const from = msg.key.remoteJid;
    const caminhoImagem = path.join(__dirname, "menu.png"); // ✅ Pega direto da pasta src/

    // ✅ LAYOUT NOVO — MESMO PADRÃO BONITO, ALINHADO E PROFISSIONAL
    const resposta = `
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』${config.BOT_NAME}『 ✦ 』
┅┄┅┄『 ✦ 』┄┅┄┅┄

🔐 Comandos Exclusivos: ${config.OWNER_NAME}

┅┄┅┄『 ✦ 』┄┅┄┅┄
 MÍDIA & FERRAMENTAS
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』 ${config.PREFIX}play [nome]   
『 ✦ 』 ${config.PREFIX}s / sticker   
『 ✦ 』 ${config.PREFIX}f / gif       
『 ✦ 』 ${config.PREFIX}toimg         
┅┄┅┄『 ✦ 』┄┅┄┅┄
 SISTEMA ECONÔMICO
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』 ${config.PREFIX}saldo        
『 ✦ 』 ${config.PREFIX}roubar @user 
『 ✦ 』 ${config.PREFIX}loja         
『 ✦ 』 ${config.PREFIX}gastar       
┅┄┅┄『 ✦ 』┄┅┄┅┄
DIVERSÃO & JOGOS
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』 ${config.PREFIX}forca         
『 ✦ 』 ${config.PREFIX}adivinha      
『 ✦ 』 ${config.PREFIX}quiz          
『 ✦ 』 ${config.PREFIX}duelo @user   
『 ✦ 』 ${config.PREFIX}roleta        
┅┄┅┄『 ✦ 』┄┅┄┅┄
CONTROLE GERAL
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』 ${config.PREFIX}ativar      
『 ✦ 』 ${config.PREFIX}desativar   
『 ✦ 』 ${config.PREFIX}configurar  
┅┄┅┄『 ✦ 』┄┅┄┅┄
🤍 Plataforma: ${config.BOT_NAME}
🌹 Sistema: ${config.BOT_NAME}
👑 Acesso: Administrador / Dono
┅┄┅┄『 ✦ 』┄┅┄┅┄
`;

    // ✅ VERIFICA SE A FOTO EXISTE — SE TIVER ENVIA COM IMAGEM, SE NÃO ENVIA SÓ TEXTO SEM DAR ERRO
    if (fs.existsSync(caminhoImagem)) {
        const bufferImagem = fs.readFileSync(caminhoImagem);
        await sock.sendMessage(from, {
            image: bufferImagem,
            caption: resposta
        }, { quoted: msg });
    } else {
        // Aviso leve se faltar a imagem — não quebra nada
        const semImagem = resposta + `\n\n⚠️ *Aviso:* Imagem do menu não encontrada!`;
        await sock.sendMessage(from, { text: semImagem }, { quoted: msg });
    }
}

module.exports = { menudono };

