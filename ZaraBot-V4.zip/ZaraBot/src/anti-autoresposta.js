// ==================================================
// 🛡️ PROTEÇÃO ANTI AUTO-RESPOSTA + MENSAGENS DO PRÓPRIO NÚMERO
// 📁 Arquivo: src/anti-autoresposta.js
//
// 1) O bot agora ACEITA COMANDOS vindos do próprio número que está
//    conectado nele (quem só tem um número consegue usar o bot).
//
// 2) Pra isso não virar uma bagunça, o bot NUNCA processa de novo o que
//    ele mesmo enviou. Toda mensagem que sai dele tem o ID guardado aqui
//    e, se ela voltar como evento, é ignorada. Assim ele não fica
//    respondendo a si mesmo (ex.: a resposta do "prefixo" contém a
//    palavra "prefixo" e antes disparava a si mesma em loop).
//
// 3) Do próprio número, só valem COMANDOS: mensagens que começam com o
//    prefixo, a palavra "menu", a palavra "prefixo" (curta) e cliques em
//    botões. Conversa normal, mídia e stickers do próprio número continuam
//    sendo ignorados — nada de respostas automáticas pra si mesmo.
//
// 4) A resposta da palavra "prefixo" só sai UMA vez por pessoa. Se a mesma
//    pessoa repetir seguido, é ignorado (sem spam). Depois de um tempo ela
//    pode pedir de novo. Tempo: PREFIXO_COOLDOWN_SEG no config.js (60 s).
// ==================================================

const config = require("../config");

let baileys = null;
try { baileys = require("@whiskeysockets/baileys"); } catch {}

// ────────────────────────────────────────────────────────────────
// 📤 IDs DAS MENSAGENS QUE O PRÓPRIO BOT ENVIOU
// ────────────────────────────────────────────────────────────────
const MAX_IDS = 5000;
const enviadas = new Map(); // id -> timestamp (a ordem de inserção = do mais antigo ao mais novo)

function lembrar(id) {
    if (!id) return;
    enviadas.set(String(id), Date.now());
    while (enviadas.size > MAX_IDS) {
        enviadas.delete(enviadas.keys().next().value);
    }
}

function foiEnviadaPeloBot(msg) {
    const id = msg?.key?.id;
    return !!id && enviadas.has(String(id));
}

function novoId(sock) {
    try {
        const gerar = baileys?.generateMessageIDV2 || baileys?.generateMessageID;
        return typeof gerar === "function" ? gerar(sock?.user?.id) : null;
    } catch {
        return null;
    }
}

// Envolve sendMessage/relayMessage do sock pra guardar o ID de TUDO que o
// bot envia. O ID é definido ANTES do envio, então não existe corrida com
// o eco da mensagem. Seguro chamar mais de uma vez no mesmo sock.
function protegerEnvios(sock) {
    if (!sock || sock.__antiAutoResposta) return sock;
    sock.__antiAutoResposta = true;

    if (typeof sock.sendMessage === "function") {
        const enviarOriginal = sock.sendMessage.bind(sock);
        sock.sendMessage = async (jid, conteudo, opcoes) => {
            const id = opcoes?.messageId || novoId(sock);
            if (id) lembrar(id);
            const resposta = await enviarOriginal(jid, conteudo, id ? { ...(opcoes || {}), messageId: id } : opcoes);
            lembrar(resposta?.key?.id);
            return resposta;
        };
    }

    if (typeof sock.relayMessage === "function") {
        const retransmitirOriginal = sock.relayMessage.bind(sock);
        sock.relayMessage = async (jid, mensagem, opcoes) => {
            lembrar(opcoes?.messageId);
            return retransmitirOriginal(jid, mensagem, opcoes);
        };
    }

    return sock;
}

// ────────────────────────────────────────────────────────────────
// 🙋 MENSAGENS DO PRÓPRIO NÚMERO
// ────────────────────────────────────────────────────────────────
function extrairTexto(msg) {
    const m = msg?.message || {};
    return (
        m.conversation ||
        m.extendedTextMessage?.text ||
        m.imageMessage?.caption ||
        m.videoMessage?.caption ||
        m.documentMessage?.caption ||
        ""
    );
}

function jidProprio(sock) {
    const bruto = sock?.user?.id || sock?.authState?.creds?.me?.id || "";
    return String(bruto).replace(/:\d+(?=@)/, "");
}

// Nas mensagens do próprio número o WhatsApp não manda quem enviou
// (principalmente no privado, onde o chat é o da OUTRA pessoa). Sem isso o
// bot acharia que quem mandou foi o outro. Aqui preenchemos com o número do bot.
function normalizarRemetentePropria(sock, msg) {
    try {
        const eu = jidProprio(sock);
        if (eu && msg?.key && !msg.key.participant) msg.key.participant = eu;
    } catch {}
}

// Decide se uma mensagem do PRÓPRIO número deve ser processada.
function deveProcessarMensagemPropria(msg, { prefix, temPendencia = false, idBotao = null } = {}) {
    if (!msg?.message) return false;

    // eco de algo que o próprio bot enviou → nunca processa
    if (foiEnviadaPeloBot(msg)) return false;

    // só conversas de verdade (grupo / privado) — nada de status, listas ou canais
    const jid = String(msg.key?.remoteJid || "");
    if (!/@(g\.us|s\.whatsapp\.net|lid)$/.test(jid)) return false;

    if (idBotao || temPendencia) return true;

    const texto = extrairTexto(msg).trim();
    if (!texto) return false;

    const p = String(prefix ?? config.PREFIX ?? "");
    if (p && texto.startsWith(p)) return true;
    if (texto.toLowerCase() === "menu") return true;
    // "prefixo" digitado de verdade é curto; textos longos com essa palavra
    // são do próprio bot ou conversa — não entram.
    if (texto.length <= 40 && /\bprefixo\b/i.test(texto)) return true;

    return false;
}

// ────────────────────────────────────────────────────────────────
// 🔑 LIMITE DA RESPOSTA "PREFIXO" — 1 por pessoa, sem repetir seguido
// ────────────────────────────────────────────────────────────────
const ultimaRespostaPrefixo = new Map(); // `${chat}|${pessoa}` -> timestamp

function janelaPrefixoMs() {
    const seg = Number(config.PREFIXO_COOLDOWN_SEG);
    return (Number.isFinite(seg) && seg >= 0 ? seg : 60) * 1000;
}

// true  = pode responder agora (e já marca que respondeu)
// false = é a mesma pessoa repetindo seguido → ignora em silêncio
function podeResponderPrefixo(chat, pessoa, agora = Date.now()) {
    const janela = janelaPrefixoMs();
    const chave = `${chat}|${pessoa}`;
    const ultima = ultimaRespostaPrefixo.get(chave) || 0;

    if (agora - ultima < janela) return false;

    ultimaRespostaPrefixo.set(chave, agora);

    if (ultimaRespostaPrefixo.size > 2000) {
        for (const [k, t] of ultimaRespostaPrefixo) {
            if (agora - t > janela) ultimaRespostaPrefixo.delete(k);
        }
    }
    return true;
}

module.exports = {
    protegerEnvios,
    foiEnviadaPeloBot,
    deveProcessarMensagemPropria,
    normalizarRemetentePropria,
    podeResponderPrefixo,
    extrairTexto,
};
