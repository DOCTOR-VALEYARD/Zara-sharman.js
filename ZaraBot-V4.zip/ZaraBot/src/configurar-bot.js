/* =================================================
   ⚙️ CONFIGURAR BOT • SISTEMA COMPLETO FUNCIONAL
   📁 Arquivo: configurar-bot.js
   ✅ ALTERAÇÕES APLICADAS IMEDIATAMENTE
================================================= */

const fs = require("fs");
const path = require("path");
const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const config = require("../config");
const { validarDono, lerDB, soNumeros } = require("./validar-dono");
const { isAdmin } = require("./grupo");

const dbPath = path.join(__dirname, "../database/botconfig.json");

function lerDBLocal() {
    if (!fs.existsSync(dbPath)) return {};
    return JSON.parse(fs.readFileSync(dbPath, "utf-8"));
}

function salvarDB(db) {
    if (!fs.existsSync(path.dirname(dbPath))) fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2), "utf-8");
}

// 📥 BAIXA MÍDIA
async function baixarMidia(msg, tipo) {
    const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
    const quotedStanzaId = msg.message?.extendedTextMessage?.contextInfo?.stanzaId;

    if (msg.message?.[tipo]) return await downloadMediaMessage(msg, "buffer", {});
    if (quotedMsg?.[tipo]) {
        const msgFake = { 
            key: { remoteJid: msg.key.remoteJid, id: quotedStanzaId || msg.key.id, participant: quotedParticipant || msg.key.participant, fromMe: false }, 
            message: quotedMsg 
        };
        return await downloadMediaMessage(msgFake, "buffer", {});
    }
    return null;
}

// 🔐 CONTROLE DE ACESSO

async function _configurarBotInterno(sock, msg, args) {
    args = args || [];
    const from = msg.key.remoteJid;
    const userId = msg.key.participant || msg.key.remoteJid;
    let db = lerDBLocal();

    // ✅ VALORES PADRÃO — SEMPRE GARANTE ALGO
    if (!db.PREFIX) db.PREFIX = config.PREFIX;
    if (!db.BOT_NAME) db.BOT_NAME = config.BOT_NAME;
    if (!db.OWNER_NAME) db.OWNER_NAME = config.OWNER_NAME;
    if (!db.OWNER_NUMBER) db.OWNER_NUMBER = config.OWNER_NUMBER;
    salvarDB(db);

    // ✅ VERIFICAÇÃO OFICIAL
    const ehRealmenteDono = validarDono(userId);
    const NOME_DONO_ATUAL = db.OWNER_NAME || config.OWNER_NAME;
    const NUMERO_DONO_ATUAL = soNumeros(db.OWNER_NUMBER || config.OWNER_NUMBER);

    // 👮 SÓ ADMIN (OU DONO) PODE MEXER NA CONFIGURAÇÃO, QUANDO USADO DENTRO DE GRUPO
    let usuarioEhAdmin = false;
    if (from.endsWith("@g.us")) {
        usuarioEhAdmin = ehRealmenteDono || await isAdmin(sock, from, userId).catch(() => false);
        if (!usuarioEhAdmin) {
            return await sock.sendMessage(from, {
                text: `╭━🚫━━━━━━━━━━━━🚫━╮\n   ❌ ACESSO NEGADO\n╰━🚫━━━━━━━━━━━━🚫━╯\n\nSó *administradores do grupo* podem mexer na configuração do bot.`
            }, { quoted: msg });
        }
    }

    // 📸 FOTO E EXIBIÇÃO
    let fotoUsuario = "https://i.imgur.com/3n8CwUl.png";
    try { fotoUsuario = await sock.profilePictureUrl(userId, "image"); } catch {}
    const exibeNumero = soNumeros(userId);

    // ==================================================
    // 🔓 SEM SENHA NENHUMA — só precisa ser admin (em grupo) ou dono (no PV)
    // ==================================================
    // Antes existia um código/senha extra pra quem não fosse admin/dono.
    // Isso foi removido de vez: quem chegou até aqui (passou pela checagem
    // de admin/dono lá em cima) já entra direto no painel.
    if (!from.endsWith("@g.us") && !ehRealmenteDono) {
        return await sock.sendMessage(from, {
            text: `🚫 Só o dono do bot pode acessar essa configuração no privado.`
        }, { quoted: msg });
    }


    // ==================================================
    // ✅ TELA PRINCIPAL — LIBERADO
    // ==================================================
    if (!args.length) {
        return await sock.sendMessage(from, {
            image: { url: fotoUsuario },
            caption: `╭━💎━━━━━━━━━━━💎━╮
    ✅ PAINEL DE CONTROLE ✅
╰━💎━━━━━━━━━━━💎━╯

👤 ADMIN: @${exibeNumero}
${ehRealmenteDono ? 
`👑 ✨ *DONA DO SISTEMA: ${NOME_DONO_ATUAL}* ✨
💫 SEJA BEM-VINDA DE VOLTA! 💫` 
: usuarioEhAdmin ? "🛡️ ADMIN DO GRUPO AUTORIZADO" : "🔑 USUÁRIA AUTORIZADA"}

╭━━━━━━━━━━━━━━━
📋 COMANDOS DISPONÍVEIS
╰━━━━━━━━━━━━━━━

🔧 ⚙️ AJUSTES GERAIS
▫️ prefixo [símbolo]   → Troca símbolo
▫️ nome [nome]         → Troca nome do bot
▫️ criadora [nome]     → Troca nome da dona
▫️ numero [com DDD]    → Troca número de dono

🖼️ 🎵 MÍDIA PERSONALIZADA
▫️ foto → Envie/marque a foto do MENU
▫️ fundo → Envie/marque a foto de FUNDO dos cards
▫️ audio → Envie/marque áudio

✨ 🎭 SISTEMA DE REAÇÕES
▫️ reacao status
▫️ reacao ligar / desligar
▫️ reacao adicionar 😊🔥
▫️ reacao resetar

📊 📋 INFORMAÇÕES
▫️ info → Ver tudo salvo

━━━━━━━━━━━━━━━━━
🤖 ${config.BOT_NAME} • ${config.OWNER_NAME}
💾 Tudo salvo automaticamente!
━━━━━━━━━━━━━━━━━`,
            mentions: [userId]
        }, { quoted: msg });
    }

    const opcao = args[0].toLowerCase();
    const valor = args.slice(1).join(" ").trim();

    // ──────────────────────────────────────────────────────────────────────
    // ✅ COMANDO: PREFIXO → TROCA E REINICIA PARA USAR NOVO
    // ──────────────────────────────────────────────────────────────────────
    if (opcao === "prefixo") {
        if (!valor) return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━⚠️━━━━━━━━⚠️━╮\n❌ Exemplo correto:\n▫️ prefixo !\n▫️ prefixo .\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        
        db.PREFIX = valor;
        salvarDB(db);

        await sock.sendMessage(from, { 
            image: { url: fotoUsuario }, 
            caption: `╭━✅━━━━━━━━✅━╮\n🔁 PREFIXO ALTERADO COM SUCESSO!\n🔑 NOVO: *${valor}*\n⏳ Reiniciando para aplicar...\n╰━━━━━━━━━━━━━━━╯` 
        }, { quoted: msg });

        setTimeout(() => process.exit(0), 2500); // Reinicia sistema
        return;
    }

    // ──────────────────────────────────────────────────────────────────────
    // ✅ COMANDO: NOME DO BOT
    // ──────────────────────────────────────────────────────────────────────
    if (opcao === "nome") {
        if (!valor) return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━⚠️━━━━━━━━⚠️━╮\n❌ Digite o novo nome!\nEx: nome MeuBot\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        
        db.BOT_NAME = valor;
        salvarDB(db);
        return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━✅━━━━━━━━✅━╮\n🤖 NOME DO BOT ALTERADO:\n✨ *${valor}*\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
    }

    // ──────────────────────────────────────────────────────────────────────
    // ✅ COMANDO: NOME DA CRIADORA / DONA
    // ──────────────────────────────────────────────────────────────────────
    if (opcao === "criadora") {
        if (!valor) return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━⚠️━━━━━━━━⚠️━╮\n❌ Digite o nome completo!\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        
        db.OWNER_NAME = valor;
        salvarDB(db);
        return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━✅━━━━━━━━✅━╮\n👑 NOME DA DONA ATUALIZADO:\n✨ *${valor}*\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
    }

    // ──────────────────────────────────────────────────────────────────────
    // ✅ COMANDO: TROCAR NÚMERO DO DONO — O MAIS IMPORTANTE
    // ──────────────────────────────────────────────────────────────────────
    if (opcao === "numero") {
        if (!valor) return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━⚠️━━━━━━━━⚠️━╮\n❌ Digite número completo com DDD!\nEx: numero 5516994306634\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        
        const novoNumeroLimpo = soNumeros(valor);
        if (novoNumeroLimpo.length < 11) return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━❌━━━━━━━━❌━╮\n❌ Número inválido! Faltam dígitos.\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });

        db.OWNER_NUMBER = novoNumeroLimpo;
        salvarDB(db);

        await sock.sendMessage(from, { 
            image: { url: fotoUsuario }, 
            caption: `╭━✅━━━━━━━━✅━╮\n📱 NÚMERO DE DONO SALVO!\n🔢 +${novoNumeroLimpo}\n💡 Agora só esse número tem acesso direto.\n╰━━━━━━━━━━━━━━━╯` 
        }, { quoted: msg });
        return;
    }

    // ──────────────────────────────────────────────────────────────────────
    // ✅ SALVAR FOTO DE FUNDO (diferente da foto do menu)
    // ──────────────────────────────────────────────────────────────────────
    if (opcao === "fundo") {
        const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const temImagem = msg.message?.imageMessage || quotedMsg?.imageMessage;

        if (!temImagem) return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━🖼️━━━━━━🖼️━╮\n📸 Envie ou marque uma IMAGEM!\n(essa vira o fundo usado nos cards\nde música, casal, perfil, etc)\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });

        try {
            const dados = await baixarMidia(msg, "imageMessage");
            if (!dados || !dados.length) {
                return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━❌━━━━━━━━❌━╮\n❌ O DOWNLOAD DA IMAGEM VEIO VAZIO!\n💡 Tente reenviar a imagem original (sem editar) e marque de novo.\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
            }

            fs.writeFileSync(path.join(__dirname, "fundo.png"), dados);
            db.BOT_FUNDO = "./src/fundo.png";
            salvarDB(db);
            return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━✅━━━━━━━━✅━╮\n🖼️ FOTO DE FUNDO ATUALIZADA!\n💡 Já vale pros próximos cards gerados.\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        } catch (erro) {
            return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━❌━━━━━━━━❌━╮\n❌ ERRO AO SALVAR:\n${erro.message}\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // ✅ SALVAR FOTO / VÍDEO DO MENU
    // ──────────────────────────────────────────────────────────────────────
    if (opcao === "foto") {
        const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const temImagem = msg.message?.imageMessage || quotedMsg?.imageMessage;
        const temVideo = msg.message?.videoMessage || quotedMsg?.videoMessage;

        if (!temImagem && !temVideo) return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━🖼️━━━━━━🖼️━╮\n📸 Envie ou marque uma IMAGEM ou VÍDEO!\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });

        try {
            const nomeArquivo = temVideo ? "menu.mp4" : "menu.png";
            const dados = await baixarMidia(msg, temVideo ? "videoMessage" : "imageMessage");

            // ✅ Checa ANTES de salvar se o download realmente veio com dados
            // (se vier vazio/corrompido, o card só ia falhar depois, sem
            // explicação nenhuma pro dono do bot — agora avisa na hora).
            if (!dados || !dados.length) {
                return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━❌━━━━━━━━❌━╮\n❌ O DOWNLOAD DA MÍDIA VEIO VAZIO!\n💡 Tente reenviar a imagem/vídeo original (sem editar) e marque de novo.\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
            }
            if (!temVideo) {
                const { detectarFormatoImagem } = require("./cardGenerator");
                console.log(`🔍 Foto do menu recebida: ${dados.length} bytes, formato real detectado: ${detectarFormatoImagem(dados)}`);
            }

            fs.writeFileSync(path.join(__dirname, nomeArquivo), dados);
            db.BOT_PHOTO = `./src/${nomeArquivo}`;
            salvarDB(db);
            return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━✅━━━━━━━━✅━╮\n📤 MÍDIA DO MENU SALVA COM SUCESSO!\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        } catch (erro) {
            return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━❌━━━━━━━━❌━╮\n❌ ERRO AO SALVAR:\n${erro.message}\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // ✅ SALVAR ÁUDIO PERSONALIZADO
    // ──────────────────────────────────────────────────────────────────────
    if (opcao === "audio") {
        const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const temAudio = msg.message?.audioMessage || quotedMsg?.audioMessage;

        if (!temAudio) return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━🎵━━━━━━🎵━╮\n🎤 Envie ou marque um ARQUIVO DE ÁUDIO!\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });

        try {
            const dados = await baixarMidia(msg, "audioMessage");
            fs.writeFileSync(path.join(__dirname, "menu_audio.mp3"), dados);
            db.BOT_AUDIO = `./src/menu_audio.mp3`;
            salvarDB(db);
            return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━✅━━━━━━━━✅━╮\n🎶 ÁUDIO PERSONALIZADO SALVO!\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        } catch (erro) {
            return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━❌━━━━━━━━❌━╮\n❌ ERRO AO SALVAR:\n${erro.message}\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // ✅ VER TODAS AS INFORMAÇÕES SALVAS
    // ──────────────────────────────────────────────────────────────────────
    if (opcao === "info") {
        const listaEmojis = (db.EMOJIS_REACAO || []).join(" ") || "❌ Nenhum cadastrado";
        const statusReacao = db.REACAO_ATIVA !== false ? "✅ ATIVADO" : "❌ DESATIVADO";

        return await sock.sendMessage(from, {
            image: { url: fotoUsuario },
            caption: `╭━📊━━━━━━━━📊━╮
 📋 DADOS GERAIS DO SISTEMA
╰━━━━━━━━━━━━━━━╯

🔹 PREFIXO ATUAL: ${db.PREFIX}
🔹 NOME DO BOT: ${db.BOT_NAME}
🔹 CRIADORA/DONA: ${db.OWNER_NAME}
🔹 NÚMERO DONO: +${NUMERO_DONO_ATUAL}

🖼️ FOTO/VÍDEO MENU: ${db.BOT_PHOTO ? "✅ SALVO" : "❌ PADRÃO"}
🎵 ÁUDIO MENU: ${db.BOT_AUDIO ? "✅ SALVO" : "❌ PADRÃO"}

🎭 REAÇÕES EM STATUS: ${statusReacao}
${listaEmojis}

━━━━━━━━━━━━━━━━━
🤖 ${config.BOT_NAME} • ${config.OWNER_NAME}
━━━━━━━━━━━━━━━━━`
        }, { quoted: msg });
    }

    // ──────────────────────────────────────────────────────────────────────
    // ✅ SISTEMA COMPLETO DE REAÇÕES
    // ──────────────────────────────────────────────────────────────────────
    if (opcao === "reacao") {
        const subComando = args[1] || "status";

        if (subComando === "status") {
            const lista = (db.EMOJIS_REACAO || []).join(" ") || "❌ Nenhum cadastrado";
            return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━🎭━━━━━━🎭━╮\n📊 SITUAÇÃO: ${db.REACAO_ATIVA !== false ? "✅ LIGADO" : "❌ DESLIGADO"}\n🎭 EMOJIS:\n${lista}\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        }

        if (subComando === "ativar" || subComando === "ligar") {
            db.REACAO_ATIVA = true; salvarDB(db);
            return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━✅━━━━━━━━✅━╮\n🎭 REAÇÕES EM STATUS: *LIGADAS!*\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        }

        if (subComando === "desativar" || subComando === "desligar") {
            db.REACAO_ATIVA = false; salvarDB(db);
            return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━❌━━━━━━━━❌━╮\n🎭 REAÇÕES EM STATUS: *DESLIGADAS!*\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        }

        if (subComando === "adicionar") {
            const novosEmojis = args.slice(2);
            if (!novosEmojis.length) return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━⚠️━━━━━━━━⚠️━╮\n❌ Exemplo: reacao adicionar 😂🔥💖\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
            
            if (!db.EMOJIS_REACAO) db.EMOJIS_REACAO = [];
            db.EMOJIS_REACAO.push(...novosEmojis);
            db.EMOJIS_REACAO = [...new Set(db.EMOJIS_REACAO)]; // Não deixa repetir
            salvarDB(db);
            return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━✅━━━━━━━━✅━╮\n🎭 ADICIONADO COM SUCESSO:\n${novosEmojis.join(" ")}\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        }

        if (subComando === "resetar") {
            db.EMOJIS_REACAO = ["👍","❤️","😂","🤔","👏","🎉","🔥","✨","💯","🌟","😍","🚀","⭐","💪","🎊","👌","🌸","💖","😎","🤩"];
            salvarDB(db);
            return await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━✅━━━━━━━━✅━╮\n🔄 LISTA DE EMOJIS PADRÃO RESTAURADA!\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
        }
    }

    // ❌ COMANDO NÃO EXISTE
    await sock.sendMessage(from, { image: { url: fotoUsuario }, caption: `╭━⚠️━━━━━━━━⚠️━╮\n❌ OPÇÃO INVÁLIDA!\nDigite apenas: ${db.PREFIX}configurar-bot\n╰━━━━━━━━━━━━━━━╯` }, { quoted: msg });
}

// 🚪 PORTA DE ENTRADA PÚBLICA — só administradores do grupo (ou o dono real)
// podem usar esse comando, e nenhum erro interno derruba o bot.
async function configurarBot(sock, msg, args) {
    const from = msg.key.remoteJid;
    const userId = msg.key.participant || msg.key.remoteJid;
    try {
        if (from.endsWith("@g.us")) {
            const souAdmin = await isAdmin(sock, from, userId);
            const souDono = validarDono(userId);
            if (!souAdmin && !souDono) {
                return await sock.sendMessage(from, {
                    text: `🔒 Esse comando só pode ser usado por *administradores do grupo*.`
                }, { quoted: msg });
            }
        }
        return await _configurarBotInterno(sock, msg, args || []);
    } catch (erro) {
        console.error("❌ Erro no configurar-bot:", erro);
        return sock.sendMessage(from, {
            text: "❌ Ocorreu um erro ao processar esse comando. Tenta de novo."
        }, { quoted: msg }).catch(() => {});
    }
}

module.exports = { configurarBot };

