const config = require("../config");
async function menupremium(sock, msg) {
    const from = msg.key.remoteJid;
    const resp = `
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』${config.BOT_NAME}『 ✦ 』
┅┄┅┄『 ✦ 』┄┅┄┅┄

  ⭐ MENU PREMIUM ⭐

┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』 💎 Recursos exclusivos
『 ✦ 』 🎁 Sem anúncios
『 ✦ 』 ⚡ Suporte prioritário
『 ✦ 』 🔥 Mais 50+ comandos
『 ✦ 』 💳 Preço: Entre em contato
┅┄┅┄『 ✦ 』┄┅┄┅┄`;
    await sock.sendMessage(from, { text: resp }, { quoted: msg });
}
module.exports = { menupremium };
