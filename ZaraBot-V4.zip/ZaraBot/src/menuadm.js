// src/menuadm.js
const config = require("../config");
const fs = require("fs");
const path = require("path");


// ═══════════════════════════════════════════════════════════════
// 🛡️ MENU ADMINISTRATIVO
// ═══════════════════════════════════════════════════════════════

async function menuadm(sock, msg) {

    const from =
        msg?.key?.remoteJid;

    if (!from) {
        return;
    }


    // ═════════════════════════════════════════════════════════════
    // 🖼️ IMAGEM DO MENU
    // ═════════════════════════════════════════════════════════════

    const caminhoImagem =
        path.join(
            __dirname,
            "menu.png"
        );


    // ═════════════════════════════════════════════════════════════
    // 📋 MENU
    // ═════════════════════════════════════════════════════════════

    const resposta = `
〔 🛡️ 𝐌𝐄𝐍𝐔 𝐀𝐃𝐌𝐈𝐍𝐈𝐒𝐓𝐑𝐀𝐓𝐈𝐕𝐎 〕
『 ⚡ ${config.BOT_NAME} 』
 └─ 🔐 Acesso exclusivo para administradores
━━━━━━━━━━━━━━━━━━━━
> ⚔️ 𝐆𝐄𝐑𝐄𝐍𝐂𝐈𝐀𝐌𝐄𝐍𝐓𝐎 𝐃𝐎 𝐆𝐑𝐔𝐏𝐎
├─ 👢 ${config.PREFIX}ban
├─ 🚫 ${config.PREFIX}kick
├─ 👑 ${config.PREFIX}promover
├─ 📉 ${config.PREFIX}rebaixar
├─ 📢 ${config.PREFIX}aviso
├─ 👥 ${config.PREFIX}marcar
├─ 📣 ${config.PREFIX}hidetag
└─ 🔓 ${config.PREFIX}abrir / fechar
━━━━━━━━━━━━━━━━━━━━
> 🔒 𝐒𝐈𝐒𝐓𝐄𝐌𝐀 𝐃𝐄 𝐒𝐄𝐆𝐔𝐑𝐀𝐍𝐂̧𝐀
├─ 🔗 ${config.PREFIX}antilink
├─ 📝 ${config.PREFIX}antinota
├─ 🎭 ${config.PREFIX}antifake
├─ 🕵️ ${config.PREFIX}x9
├─ 👋 Boas-vindas / Saída
├─ 🗑️ Anti-Delete
└─ ⚙️ ${config.PREFIX}ativar / desativar
━━━━━━━━━━━━━━━━━━━━
> 📊 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐂̧𝐎̃𝐄𝐒 & 𝐀𝐂𝐄𝐒𝐒𝐎
├─ 👮 ${config.PREFIX}adms
├─ 🔗 ${config.PREFIX}convite
├─ ⚠️ ${config.PREFIX}infoadv
└─ 🔇 ${config.PREFIX}infomute
━━━━━━━━━━━━━━━━━
│〔 ⚡ 𝐀𝐃𝐌𝐈𝐍 𝐂𝐎𝐍𝐓𝐑𝐎𝐋 〕
├─ 🤖 Sistema: ${config.BOT_NAME}
├─ 👑 Responsável: ${config.OWNER_NAME}
├─ 🔐 Acesso: Administrativo
└─ 🟢 Status: Operacional
━━━━━━━━━━━━━━━━━
🤍 ${config.BOT_NAME}
🌹 ${config.OWNER_NAME}
━━━━━━━━━━━━━━━━━`;


    // ═════════════════════════════════════════════════════════════
    // 📤 ENVIO
    // ═════════════════════════════════════════════════════════════

    try {

        if (fs.existsSync(caminhoImagem)) {

            const bufferImagem =
                fs.readFileSync(
                    caminhoImagem
                );


            await sock.sendMessage(
                from,
                {
                    image: bufferImagem,
                    caption: resposta
                },
                {
                    quoted: msg
                }
            );

            return;
        }


        // ─────────────────────────────────────────────────────────
        // ⚠️ FALLBACK SEM IMAGEM
        // ─────────────────────────────────────────────────────────

        await sock.sendMessage(
            from,
            {
                text:
                    `${resposta}\n\n` +
                    `⚠️ *Imagem do menu não localizada.*`
            },
            {
                quoted: msg
            }
        );

    } catch (erro) {

        console.error(
            "❌ Erro ao enviar menu administrativo:",
            erro
        );
    }
}


// ═══════════════════════════════════════════════════════════════
// 📦 EXPORTAÇÃO
// ═══════════════════════════════════════════════════════════════

module.exports = {
    menuadm
};