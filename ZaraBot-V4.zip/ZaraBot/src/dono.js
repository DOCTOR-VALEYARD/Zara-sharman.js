// src/dono.js
const config = require("../config");
const fs = require("fs");
const path = require("path");

// ==================================================
// 👑 DADOS FIXOS DO CRIADOR — NÃO MUDAM POR CONFIGURAÇÃO
// ==================================================
// Estes dados ficam AQUI, neste arquivo. Não vêm do config.js nem do
// database/botconfig.json, então ninguém troca pelo ".configurar-bot numero".
// O botão "FALAR COM O CRIADOR" e o comando ".dono" usam sempre este número.
const CRIADOR_FIXO = Object.freeze({
    nome: "Doctor Valeyard C'rizz Lunático",
    apelido: "DOCTOR VALEYARD",
    numero: "5516998761099",
    criadoEm: "2026-06-30", // data em que o bot começou a ser criado
});

function linkCriador(mensagem = "Olá! Vim pelo bot e queria falar com o criador.") {
    return `https://wa.me/${CRIADOR_FIXO.numero}?text=${encodeURIComponent(mensagem)}`;
}

function formatarIdade(desde, agora = new Date()) {
    const d = new Date(`${desde}T12:00:00`);
    let meses = (agora.getFullYear() - d.getFullYear()) * 12 + (agora.getMonth() - d.getMonth());
    if (agora.getDate() < d.getDate()) meses -= 1;
    if (meses < 0) meses = 0;
    if (meses < 1) {
        const dias = Math.max(0, Math.floor((agora - d) / 86400000));
        return `${dias} ${dias === 1 ? "dia" : "dias"}`;
    }
    const anos = Math.floor(meses / 12);
    const resto = meses % 12;
    const partes = [];
    if (anos) partes.push(`${anos} ${anos === 1 ? "ano" : "anos"}`);
    if (resto) partes.push(`${resto} ${resto === 1 ? "mês" : "meses"}`);
    return partes.join(" e ");
}

// Conta os comandos de verdade lendo o zarabot.js (aliases do mesmo comando
// contam como UM só; ids internos de botão "menu_*" ficam de fora).
let _cacheContagem = null;
function contarComandos() {
    if (_cacheContagem !== null) return _cacheContagem;
    try {
        const fonte = fs.readFileSync(path.join(__dirname, "..", "zarabot.js"), "utf8");
        const unicos = new Set();
        let total = 0;
        let grupoAberto = false;
        for (const linha of fonte.split("\n")) {
            const labels = [...linha.matchAll(/case\s+"([^"]+)"\s*:/g)];
            if (!labels.length) { continue; }
            const nomes = labels.map(m => m[1]).filter(n => !n.startsWith("menu_"));
            const resto = linha.replace(/case\s+"[^"]+"\s*:/g, "").trim();
            if (nomes.length && !grupoAberto) {
                if (nomes.some(n => !unicos.has(n))) total++;
            }
            nomes.forEach(n => unicos.add(n));
            grupoAberto = resto === "" ; // continua no grupo se a linha só tinha rótulos
        }
        _cacheContagem = total;
    } catch {
        _cacheContagem = 0;
    }
    return _cacheContagem;
}

function textoInfoDono() {
    const p = config.PREFIX;
    const criado = new Date(`${CRIADOR_FIXO.criadoEm}T12:00:00`);
    const dataBR = criado.toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });
    const idade = formatarIdade(CRIADOR_FIXO.criadoEm);
    const comandos = contarComandos();

    return `╭─── ❀ ───╮
   👑 CRIADOR DO BOT 👑
╰─── ❀ ───╯

❀ 👤 Criador: *${CRIADOR_FIXO.nome}*
❀ 📱 Contato: wa.me/${CRIADOR_FIXO.numero}
❀ 🤖 Bot: *${config.BOT_NAME}* ${config.VERSION ? `(${config.VERSION})` : ""}

❀ 📅 Criado em: *${dataBR}*
❀ ⏳ Tempo de vida: *${idade}*
❀ ⚙️ Comandos: *${comandos}*

❀────────────────────❀
🚀 Eu, *${CRIADOR_FIXO.apelido}*, estou sempre evoluindo este bot para deixá-lo cada vez melhor e mais excepcional!
💡 Tem sugestão ou achou um bug? Fale comigo pelo botão abaixo ou use *${p}sugestao* e *${p}bug*.
❀────────────────────❀
🤍 ${config.BOT_NAME}`;
}

// Mensagem do comando ".dono" (e do botão de crédito do menu)
const infoDono = async (sock, from, msg) => {
    const texto = textoInfoDono();
    const opcoes = msg ? { quoted: msg } : undefined;
    try {
        const { enviarNativeFlow, botaoUrl } = require("./menuBotoes");
        const caminhoImagem = path.join(__dirname, "menu.png");
        const midia = fs.existsSync(caminhoImagem) ? { imageBuffer: fs.readFileSync(caminhoImagem) } : {};
        return await enviarNativeFlow(sock, from, {
            text: texto,
            footer: config.BOT_NAME,
            quoted: msg,
            buttons: [botaoUrl("💬 FALAR COM O CRIADOR", linkCriador())],
            ...midia,
        });
    } catch (erro) {
        console.error("⚠️ Botão do .dono falhou, mandando em texto:", erro?.message || erro);
        return sock.sendMessage(from, { text: `${texto}\n\n💬 ${linkCriador()}` }, opcoes);
    }
};


const responderDono = async (sock, from, msg) => {
    const caminhoImagem = path.join(__dirname, "menu.png");

    const frasesAutoridade = [
        "⚠️ Você não tem autoridade para me marcar ou contatar minha liderança!",
        "🚫 Cuidado com esse contato. Acesso restrito apenas a níveis superiores!",
        "🛑 Canal exclusivo. Você não possui permissão para acessar essa área!",
        "⚠️ Meu criador está ocupado com assuntos importantes. Não incomode sem autorização!",
        "🔒 Tentativa de acesso detectada. Contato com a liderança: AUTORIDADE NEGADA!"
    ];

    const fraseAleatoria = frasesAutoridade[Math.floor(Math.random() * frasesAutoridade.length)];
    const dataAtual = new Date().toLocaleDateString('pt-BR');
    const horaAtual = new Date().toLocaleTimeString('pt-BR');

    // ✅ TUDO VINDO DIRETO DO CONFIG — NENHUM NOME FIXO
    const mensagem = `
╭─── ❀ ───╮
   🔐 ACESSO RESTRITO 🔐
╰─── ❀ ───╯

❀ ⚠️ AVISO DE SEGURANÇA ❀
${fraseAleatoria}

❀ 👤 DADOS DO CRIADOR ❀
❀ Nome Principal: *${config.OWNER_NAME}*
❀ Contato: wa.me/${config.OWNER_NUMBER}
❀ Situação: Ocupado • Desenvolvimento
❀ Disponibilidade: Apenas convidados

❀ 📌 INFORMAÇÕES DO SISTEMA ❀
❀ Plataforma: ${config.BOT_NAME}
❀ Sistema: *${config.BOT_NAME}*
❀ Versão: ${config.VERSION}

❀ 🕒 REGISTRO DE CONSULTA ❀
❀ 📅 Data: ${dataAtual}
❀ 🕒 Hora: ${horaAtual}

❀────────────────────❀
🤍 ${config.BOT_NAME}
🌹 ${config.OWNER_NAME}
❀────────────────────❀
`;

    // ✅ ENVIA COM IMAGEM PADRÃO
    if (fs.existsSync(caminhoImagem)) {
        const buffer = fs.readFileSync(caminhoImagem);
        await sock.sendMessage(from, {
            image: buffer,
            caption: mensagem
        }, { quoted: msg });
    } else {
        await sock.sendMessage(from, { text: mensagem }, { quoted: msg });
    }
};

module.exports = { responderDono, infoDono, textoInfoDono, contarComandos, linkCriador, CRIADOR_FIXO };
