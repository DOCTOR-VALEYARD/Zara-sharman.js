// ================================================================
// 🔘 MENU COM BOTÕES — ZARA BOT (Native Flow / Quick Reply)
// 📁 Arquivo: src/menuBotoes.js
// Compatível com @whiskeysockets/baileys 7.0.0-rc.9+
//
// Mesma ideia do Mikasa Bot:
//   • "<prefixo>menu"  → manda o crédito do criador e depois o menu com
//                        BOTÕES (foto do menu no topo).
//   • "menu" (sem prefixo) → menu normal em texto (ver src/menu.js).
//   • O menu tem só 3 botões: PRINCIPAL (lista nativa com todos os comandos),
//     CONFIGURAÇÃO (lista nativa de configuração) e FALAR COM O CRIADOR.
//     As listas abrem direto — sem mensagem intermediária.
//
// ⚠️ AVISO: botões interativos (nativeFlowMessage) usam um recurso NÃO
// OFICIAL do WhatsApp. Dependendo da versão do app da pessoa, o botão
// pode não aparecer ou o clique pode não chegar no bot. Por isso o menu
// em texto ("menu" sem prefixo) continua existindo como alternativa — e
// se o envio dos botões falhar, o bot cai sozinho pro menu em texto.
// ================================================================
const fs = require("fs");
const path = require("path");
const config = require("../config");

const baileys = require("@whiskeysockets/baileys");
const {
  generateWAMessageFromContent,
  normalizeMessageContent,
  prepareWAMessageMedia,
  isJidGroup,
  generateMessageIDV2,
  generateMessageID,
} = baileys;

// ────────────────────────────────────────────────────────────────
// 🧱 BLOCOS BÁSICOS
// ────────────────────────────────────────────────────────────────
function botao(displayText, id) {
  return {
    name: "quick_reply",
    buttonParamsJson: JSON.stringify({ display_text: displayText, id }),
  };
}

function botaoUrl(displayText, url) {
  return {
    name: "cta_url",
    buttonParamsJson: JSON.stringify({ display_text: displayText, url }),
  };
}

function botaoLista(displayText, sections) {
  return {
    name: "single_select",
    buttonParamsJson: JSON.stringify({ title: displayText, sections }),
  };
}

function linhaLista(id, titulo, descricao = "") {
  return {
    id,
    title: String(titulo).slice(0, 24),
    description: String(descricao || "").slice(0, 72),
  };
}

function getButtonNode(message) {
  const nativeFlow = message?.interactiveMessage?.nativeFlowMessage;
  const firstName = nativeFlow?.buttons?.[0]?.name;

  if (nativeFlow && (firstName === "review_and_pay" || firstName === "payment_info")) {
    return {
      tag: "biz",
      attrs: { native_flow_name: firstName === "review_and_pay" ? "order_details" : firstName },
    };
  }

  if (nativeFlow) {
    return {
      tag: "biz",
      attrs: {},
      content: [{
        tag: "interactive",
        attrs: { type: "native_flow", v: "1" },
        content: [{ tag: "native_flow", attrs: { v: "9", name: "mixed" } }],
      }],
    };
  }

  return null;
}

// Mantém a mensagem interativa dentro do wrapper aceito pelo WhatsApp.
function patchInteractiveMessage(message) {
  if (!message || message.documentWithCaptionMessage?.message) return message;
  if (message.interactiveMessage) {
    return { documentWithCaptionMessage: { message } };
  }
  return message;
}

// Envia uma mensagem de botões (com foto/vídeo no topo, se vier).
async function enviarNativeFlow(sock, jid, { text, footer, buttons, imageBuffer, videoBuffer, gifPlayback = false, quoted, mentions }) {
  if (typeof generateWAMessageFromContent !== "function" || typeof sock.relayMessage !== "function") {
    throw new Error("Baileys não expôs generateWAMessageFromContent/relayMessage.");
  }

  const nomeBot = config.BOT_NAME || "Zara Bot";

  const interactive = {
    body: { text },
    footer: { text: footer || nomeBot },
    nativeFlowMessage: {
      buttons: buttons.map(b => ({ name: b.name, buttonParamsJson: b.buttonParamsJson })),
      messageParamsJson: "",
    },
    ...(Array.isArray(mentions) && mentions.length ? { contextInfo: { mentionedJid: mentions } } : {}),
  };

  if ((imageBuffer || videoBuffer) && typeof prepareWAMessageMedia === "function") {
    const media = await prepareWAMessageMedia(
      videoBuffer ? { video: videoBuffer, gifPlayback } : { image: imageBuffer },
      { upload: sock.waUploadToServer }
    );
    interactive.header = { title: nomeBot, hasMediaAttachment: true, ...media };
  } else {
    interactive.header = { title: nomeBot, hasMediaAttachment: false };
  }

  const userJid = sock.authState?.creds?.me?.id || sock.user?.id;
  const makeId = generateMessageIDV2 || generateMessageID;
  const messageId = typeof makeId === "function" ? makeId(userJid) : undefined;

  const generated = generateWAMessageFromContent(jid, { interactiveMessage: interactive }, {
    logger: sock.logger,
    userJid,
    messageId,
    timestamp: new Date(),
    quoted,
  });

  const normalized = typeof normalizeMessageContent === "function"
    ? normalizeMessageContent(generated.message)
    : generated.message;

  const additionalNodes = [];
  const buttonNode = getButtonNode(normalized);
  if (buttonNode) additionalNodes.push(buttonNode);

  // Conversas privadas precisam do nó bot/biz_bot para o fluxo interativo.
  if (typeof isJidGroup === "function" ? !isJidGroup(jid) : !String(jid).endsWith("@g.us")) {
    additionalNodes.push({ tag: "bot", attrs: { biz_bot: "1" } });
  }

  generated.message = patchInteractiveMessage(generated.message);

  await sock.relayMessage(jid, generated.message, {
    messageId: generated.key.id,
    additionalNodes,
  });

  return generated;
}

// ────────────────────────────────────────────────────────────────
// 🗂️ CATEGORIAS — espelham EXATAMENTE as seções do menu em texto
// (src/menu.js). Só entram comandos que existem no zarabot.js.
// ────────────────────────────────────────────────────────────────
const CATEGORIAS = {
  "⚙️ CONFIGS": ["ping", "dono", "configurar-bot", "ativar", "ia"],
  "💻 MENUS": ["menudono", "menuadm", "menupremium", "menugold", "menumidias", "efeitos", "logos", "brincadeiras"],
  "👥 MEMBROS": [
    "registrar", "delregistro", "perfil", "inforegistrar", "infoperfil", "advertidos", "mutados",
    "infoadv", "infomute", "infobot", "bug", "sugestao", "avalie", "reagir", "adms", "convite",
    "forca", "adivinha", "quiz", "jogodavelha", "aleatory", "resumo",
  ],
  "📚 INFOS": ["rank", "moedas", "esporte_noticias", "celular", "letramusica", "tempo"],
  "⚡ COMANDOS": [
    "gtts", "tomp3", "gif", "s", "roubar", "signo", "casal", "saldo", "loja",
    "duelo", "roleta", "play", "sortear", "spam", "resgatar",
  ],
};

const TODOS_OS_COMANDOS = new Set(Object.values(CATEGORIAS).flat());

const DESCRICOES = {
  ping: "Ver se o bot está respondendo.",
  dono: "Quem criou o bot, quando e quantos comandos.",
  "configurar-bot": "Abrir o painel de configuração.",
  ativar: "Ativar o bot neste grupo.",
  ia: "Ligar/desligar a inteligência artificial.",
  menudono: "Menu do dono.",
  menuadm: "Menu dos administradores.",
  menupremium: "Menu premium.",
  menugold: "Menu de gold e economia.",
  menumidias: "Menu de downloads e mídias.",
  efeitos: "Efeitos para suas imagens.",
  logos: "Criar logos com o seu texto.",
  brincadeiras: "Lista de brincadeiras.",
  registrar: "Criar o seu registro.",
  delregistro: "Apagar o seu registro.",
  perfil: "Ver o seu perfil.",
  inforegistrar: "Como funciona o registro.",
  infoperfil: "Como funciona o perfil.",
  advertidos: "Lista de advertidos.",
  mutados: "Lista de mutados.",
  infoadv: "Como funcionam as advertências.",
  infomute: "Como funciona o mute.",
  infobot: "Informações do bot.",
  bug: "Reportar um bug.",
  sugestao: "Enviar uma sugestão.",
  avalie: "Avaliar o bot.",
  reagir: "Reagir a uma mensagem.",
  adms: "Chamar os administradores.",
  convite: "Link de convite do grupo.",
  forca: "Jogo da forca.",
  adivinha: "Jogo de adivinhação.",
  quiz: "Quiz de perguntas.",
  jogodavelha: "Jogo da velha.",
  aleatory: "Algo aleatório.",
  resumo: "Resumo da conversa.",
  rank: "Ranking do grupo.",
  moedas: "Ver suas moedas.",
  esporte_noticias: "Notícias de esporte.",
  celular: "Buscar celulares por marca.",
  letramusica: "Buscar letra de música.",
  tempo: "Previsão do tempo da cidade.",
  gtts: "Transformar texto em áudio.",
  tomp3: "Converter vídeo/áudio em MP3.",
  gif: "Converter em GIF/imagem.",
  s: "Criar figurinha.",
  roubar: "Salvar uma figurinha com um nome.",
  signo: "Horóscopo do signo.",
  casal: "Formar um casal.",
  saldo: "Ver o seu saldo.",
  loja: "Abrir a loja.",
  duelo: "Desafiar alguém pra um duelo.",
  roleta: "Girar a roleta.",
  play: "Baixar música pelo nome.",
  sortear: "Sortear entre opções.",
  spam: "Enviar mensagens repetidas.",
  resgatar: "Resgatar um token.",
};

// Comandos que precisam de um dado a mais: o botão pergunta e a PRÓXIMA
// mensagem da pessoa vira o argumento do comando.
const ENTRADA = {
  play: "🎵 Qual música você deseja baixar?\n\nDigite somente o nome da música.",
  gtts: "🗣️ Envie o *idioma* e o *texto*.\nEx.: pt Olá, tudo bem?",
  letramusica: "🎶 Qual música? Digite o nome (e o artista, se quiser).",
  logos: "🖌️ Digite o texto que vai na logo.",
  registrar: "📝 Digite o nome que você quer usar no registro.",
  tempo: "🌦️ Digite a cidade.\nEx.: campinas",
  celular: "📱 Digite a marca do celular.\nEx.: Xiaomi",
  signo: "✨ Digite o seu signo.\nEx.: Áries",
  roubar: "🎴 *Responda* uma figurinha, imagem, vídeo ou GIF escrevendo o *nome* que você quer dar a ela.",
  duelo: "⚔️ Marque (@) quem você quer desafiar.",
  resgatar: "🎁 Digite o código do token.",
  spam: "📨 Envie o número e a quantidade.\nEx.: 5511999999999 8",
  sortear: "🎲 Digite as opções separadas por vírgula.\nEx.: Opção A, Opção B",
};

// Comandos que dependem de uma mídia/resposta: o botão só orienta.
function instrucaoMidia(cmd) {
  const p = config.PREFIX;
  const mapa = {
    s: `🖼️ Envie uma *imagem ou vídeo* com *${p}s* na legenda, ou *responda* a mídia com *${p}s*.`,
    gif: `🎞️ *Responda* uma figurinha, imagem ou vídeo com *${p}gif* para converter.`,
    tomp3: `🎧 *Responda* um vídeo ou áudio com *${p}tomp3* para converter em MP3.`,
  };
  return mapa[cmd] || null;
}

// ────────────────────────────────────────────────────────────────
// ⏳ ESTADO "AGUARDANDO O QUE FALTA" (5 minutos)
// ────────────────────────────────────────────────────────────────
const INTERACTIVE_PENDING = new Map();

function getPendingKey(msg) {
  const jid = msg?.key?.remoteJid || "";
  const user = msg?.key?.participant || msg?.key?.participantAlt || jid;
  return `${jid}|${user}`;
}

function setInteractivePending(msg, data) {
  INTERACTIVE_PENDING.set(getPendingKey(msg), { ...data, at: Date.now() });
}

function getInteractivePending(msg) {
  const key = getPendingKey(msg);
  const item = INTERACTIVE_PENDING.get(key);
  if (!item) return null;
  if (Date.now() - item.at > 5 * 60 * 1000) {
    INTERACTIVE_PENDING.delete(key);
    return null;
  }
  return item;
}

function clearInteractivePending(msg) {
  INTERACTIVE_PENDING.delete(getPendingKey(msg));
}

// ────────────────────────────────────────────────────────────────
// 🖼️ FOTO DO MENU — sempre a que está em src/menu.png (ou menu.mp4)
// ────────────────────────────────────────────────────────────────
function lerBotConfigAtual() {
  try {
    const dbPath = path.join(__dirname, "../database/botconfig.json");
    if (!fs.existsSync(dbPath)) return {};
    return JSON.parse(fs.readFileSync(dbPath, "utf8")) || {};
  } catch {
    return {};
  }
}

// Versão leve (1000px, JPEG) da foto, guardada em memória — evita subir
// 2 MB do menu.png a cada clique. Se algo falhar, usa o arquivo original.
let _cacheFoto = { chave: null, buffer: null };

async function fotoMenuLeve() {
  const arquivo = path.join(__dirname, "menu.png");
  if (!fs.existsSync(arquivo)) return null;

  const st = fs.statSync(arquivo);
  const chave = `${st.size}-${st.mtimeMs}`;
  if (_cacheFoto.chave === chave && _cacheFoto.buffer) return _cacheFoto.buffer;

  const original = fs.readFileSync(arquivo);
  let buffer = original;
  try {
    const { createCanvas, loadImage } = require("@napi-rs/canvas");
    const img = await loadImage(original);
    const W = Math.min(1000, img.width);
    const H = Math.max(1, Math.round(img.height * (W / img.width)));
    const canvas = createCanvas(W, H);
    canvas.getContext("2d").drawImage(img, 0, 0, W, H);
    buffer = canvas.toBuffer("image/jpeg", 85);
  } catch (e) {
    console.error("⚠️ Não consegui reduzir a foto do menu, usando a original:", e?.message || e);
    buffer = original;
  }

  _cacheFoto = { chave, buffer };
  return buffer;
}

// Mídia que vai no topo dos botões.
//   principal = true → o mesmo card do menu antigo (foto + nomes + foto do grupo)
//   principal = false → só a foto (listas internas)
async function obterMidiaMenu(sock, jid, { principal = false } = {}) {
  try {
    const caminhoVideo = path.join(__dirname, "menu.mp4");
    if (fs.existsSync(caminhoVideo)) {
      return { videoBuffer: fs.readFileSync(caminhoVideo) };
    }

    if (principal) {
      try {
        const db = lerBotConfigAtual();
        const { criarCardMenu } = require("./cardGenerator");
        const { buscarFotoContexto } = require("./foto-contexto");
        const fotoPath = path.join(__dirname, "menu.png");
        const fotoBuffer = fs.existsSync(fotoPath) ? fs.readFileSync(fotoPath) : null;
        const fotoContextoBuffer = await buscarFotoContexto(sock, jid);
        const card = await criarCardMenu({
          fotoBuffer,
          botName: db.BOT_NAME || config.BOT_NAME || "BOT",
          ownerName: db.OWNER_NAME || config.OWNER_NAME || "Desconhecida",
          fotoContextoBuffer,
        });
        if (card) return { imageBuffer: card };
      } catch (e) {
        console.error("⚠️ Card do menu falhou, usando só a foto:", e?.message || e);
      }
    }

    const foto = await fotoMenuLeve();
    return foto ? { imageBuffer: foto } : {};
  } catch (e) {
    console.error("⚠️ Não consegui carregar a foto do menu:", e?.message || e);
    return {};
  }
}

// 🔊 Áudio do menu — o mesmo comportamento do menu em texto.
async function enviarAudioDoMenu(sock, jid) {
  let enviou = false;
  try {
    const { enviarAudioDaPasta } = require("./audio-pastas");
    enviou = await enviarAudioDaPasta(sock, jid, "menu");
  } catch {
    console.log("Áudio da pasta 'menu' indisponível, tentando áudio configurado...");
  }

  if (!enviou) {
    const db = lerBotConfigAtual();
    if (db.BOT_AUDIO && fs.existsSync(db.BOT_AUDIO)) {
      try {
        await sock.sendMessage(jid, { audio: fs.readFileSync(db.BOT_AUDIO), mimetype: "audio/mp4" });
      } catch {
        console.log("Áudio não encontrado, pulando...");
      }
    }
  }
}

// ────────────────────────────────────────────────────────────────
// 🔗 LINKS
// ────────────────────────────────────────────────────────────────
function obterLinkCanalConfig() {
  const valor = [config.CHANNEL_URL, config.CHANNEL_LINK, config.CANAL_URL, config.CANAL_LINK]
    .find(v => typeof v === "string" && v.trim());
  if (!valor) return null;

  const limpo = valor.trim();
  if (/^https?:\/\//i.test(limpo)) return limpo;
  if (/^(whatsapp\.com\/channel\/|wa\.me\/)/i.test(limpo)) return `https://${limpo}`;
  return null;
}

// 🔒 SEMPRE o número FIXO do criador (src/dono.js) — nunca o da configuração.
function linkFalarComCriador() {
  try {
    return require("./dono").linkCriador();
  } catch {
    return null;
  }
}

function botaoFalarComCriador() {
  const criador = linkFalarComCriador();
  return criador ? botaoUrl("💬 FALAR COM O CRIADOR", criador) : null;
}

function botoesDeLink() {
  const canal = obterLinkCanalConfig();
  const lista = [];
  if (canal) lista.push(botaoUrl("📢 ENTRAR NO CANAL", canal));
  const criador = botaoFalarComCriador();
  if (criador) lista.push(criador);
  return lista;
}

// ────────────────────────────────────────────────────────────────
// 📋 LISTAS NATIVAS (abrem direto, sem mensagem intermediária)
// ────────────────────────────────────────────────────────────────
function secoesPrincipal() {
  const prefix = config.PREFIX;
  const sections = [];
  for (const [nome, comandos] of Object.entries(CATEGORIAS)) {
    for (let i = 0; i < comandos.length; i += 10) {
      const bloco = comandos.slice(i, i + 10);
      sections.push({
        title: (comandos.length > 10 ? `${nome} ${Math.floor(i / 10) + 1}` : nome).slice(0, 24),
        rows: bloco.map(c => linhaLista(`cmd:${c}`, `${prefix}${c}`, DESCRICOES[c] || `Executar ${prefix}${c}`)),
      });
    }
  }
  return sections;
}

// Opções do painel de configuração (ver src/configurar-bot.js)
const CONFIG_OPCOES = [
  { id: "painel",        titulo: "Painel de controle",  desc: "Abrir o painel completo de configuração." },
  { id: "info",          titulo: "Ver tudo salvo",      desc: "Mostrar todas as configurações atuais." },
  { id: "prefixo",       titulo: "Trocar prefixo",      desc: "Muda o símbolo dos comandos (reinicia o bot).", pergunta: "🔑 Digite o *novo prefixo*.\nEx.: ! ou /" },
  { id: "nome",          titulo: "Nome do bot",         desc: "Troca o nome do bot.", pergunta: "🤖 Digite o *novo nome* do bot." },
  { id: "criadora",      titulo: "Nome da dona",        desc: "Troca o nome da dona do bot.", pergunta: "👑 Digite o *nome da dona/criadora*." },
  { id: "numero",        titulo: "Número de dono",      desc: "Troca o número de dono do bot.", pergunta: "📱 Digite o *número com DDD* (só números).\nEx.: 5511999999999" },
  { id: "foto",          titulo: "Foto/vídeo do menu",  desc: "Envia/marca a mídia que aparece no menu.", instrucao: "foto" },
  { id: "fundo",         titulo: "Fundo dos cards",     desc: "Envia/marca a imagem de fundo dos cards.", instrucao: "fundo" },
  { id: "audio",         titulo: "Áudio do menu",       desc: "Envia/marca o áudio personalizado.", instrucao: "audio" },
  { id: "reacao_status", titulo: "Reações: situação",   desc: "Ver se as reações em status estão ligadas." },
  { id: "reacao_ligar",  titulo: "Reações: ligar",      desc: "Ligar as reações automáticas em status." },
  { id: "reacao_desligar", titulo: "Reações: desligar", desc: "Desligar as reações automáticas em status." },
  { id: "reacao_add",    titulo: "Reações: adicionar",  desc: "Adicionar emojis à lista de reações.", pergunta: "🎭 Digite os *emojis* separados por espaço.\nEx.: 😊 🔥 💖" },
  { id: "reacao_reset",  titulo: "Reações: resetar",    desc: "Voltar à lista padrão de emojis." },
];

// id da opção → argumentos do ".configurar-bot" (quando não precisa de texto)
const CONFIG_ARGS = {
  painel: "",
  info: "info",
  reacao_status: "reacao status",
  reacao_ligar: "reacao ligar",
  reacao_desligar: "reacao desligar",
  reacao_reset: "reacao resetar",
};
// id da opção → o que vem antes do texto digitado
const CONFIG_PENDENTE = {
  prefixo: "prefixo",
  nome: "nome",
  criadora: "criadora",
  numero: "numero",
  reacao_add: "reacao adicionar",
};

function secoesConfiguracao() {
  const prefix = config.PREFIX;
  return [{
    title: "CONFIGURAÇÃO DO BOT",
    rows: CONFIG_OPCOES.map(o => linhaLista(`cfg:${o.id}`, o.titulo, o.desc)),
  }];
}

// Lista nativa genérica (usada também pela música aleatória).
async function enviarListaWhatsApp(sock, jid, { text, title, footer, quoted, sections, botaoTexto = "📋 ABRIR LISTA" }) {
  const botoes = [botaoLista(botaoTexto, sections)];
  try {
    return await enviarNativeFlow(sock, jid, { text, footer, quoted, buttons: botoes });
  } catch (erro) {
    console.error("⚠️ Falha ao enviar lista:", erro?.message || erro);
    const linhas = sections.flatMap(sec => sec.rows.map(r => `『 ✦ 』 ${r.title}`)).join("\n");
    return sock.sendMessage(jid, { text: `${title || ""}\n\n${text}\n\n${linhas}` }, { quoted });
  }
}

// ────────────────────────────────────────────────────────────────
// 🏠 MENU PRINCIPAL — SÓ 3 BOTÕES
//   1) PRINCIPAL            → lista nativa do WhatsApp com TODOS os comandos
//   2) CONFIGURAÇÃO         → lista nativa com as opções de configuração
//   3) FALAR COM O CRIADOR  → link direto (número fixo do src/dono.js)
// ────────────────────────────────────────────────────────────────
async function sendMenuBotoes(sock, jid, msg, opcoes = {}) {
  const db = lerBotConfigAtual();
  const prefix = config.PREFIX;
  const botName = db.BOT_NAME || config.BOT_NAME || "BOT";
  const ownerName = db.OWNER_NAME || config.OWNER_NAME || "Desconhecida";

  // 🔊 mesmo áudio do menu em texto (só no menu principal, não ao voltar)
  if (opcoes.audio !== false) {
    await enviarAudioDoMenu(sock, jid);
  }

  const texto =
`┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』${botName}『 ✦ 』
┅┄┅┄『 ✦ 』┄┅┄┅┄

👤 ${ownerName}
🤖 『 ✦ 』${botName}『 ✦ 』
💡 ${prefix}ping • ${prefix}ativar • ${prefix}dono

Toque em *PRINCIPAL* para ver os comandos.
Prefere em texto? Digite *menu* (sem prefixo).`;

  const botoes = [
    botaoLista("📋 PRINCIPAL", secoesPrincipal()),
    botaoLista("⚙️ CONFIGURAÇÃO", secoesConfiguracao()),
    botaoFalarComCriador(),
  ].filter(Boolean);

  const midia = await obterMidiaMenu(sock, jid, { principal: true });

  try {
    return await enviarNativeFlow(sock, jid, {
      text: texto,
      footer: config.VERSION ? `${botName} • ${config.VERSION}` : botName,
      quoted: opcoes.quoted,
      buttons: botoes,
      ...midia,
    });
  } catch (erro) {
    console.error("⚠️ Falha ao enviar o menu com botões:", erro?.message || erro);
  }

  // 🛟 1ª tentativa de socorro: os mesmos botões, sem a mídia.
  try {
    return await enviarNativeFlow(sock, jid, { text: texto, quoted: opcoes.quoted, buttons: botoes });
  } catch (erro) {
    console.error("⚠️ Falha também sem mídia:", erro?.message || erro);
  }

  // 🛟 2ª tentativa: menu normal em texto (com a foto), pra NUNCA ficar sem menu.
  const { menu } = require("./menu");
  return menu(sock, jid);
}

// ────────────────────────────────────────────────────────────────
// 👆 LEITURA DO CLIQUE
// ────────────────────────────────────────────────────────────────
function extrairIdBotaoClicado(msg) {
  // O WhatsApp/Baileys pode entregar a resposta do clique dentro de
  // wrappers (ephemeral, viewOnce, documentWithCaption, etc.) e em
  // formatos diferentes conforme a versão do app. Aqui procuramos em
  // todos eles.
  try {
    const raiz = msg?.message;
    if (!raiz) return null;

    const visitados = new Set();
    const fila = [raiz];
    const wrappers = [
      "ephemeralMessage",
      "viewOnceMessage",
      "viewOnceMessageV2",
      "viewOnceMessageV2Extension",
      "documentWithCaptionMessage",
      "editedMessage",
      "deviceSentMessage",
      "associatedChildMessage",
    ];

    while (fila.length) {
      const atual = fila.shift();
      if (!atual || typeof atual !== "object" || visitados.has(atual)) continue;
      visitados.add(atual);

      const paramsJson = atual.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson;
      if (paramsJson) {
        try {
          const dados = JSON.parse(paramsJson);
          return dados.id || dados.row_id || dados.selectedId || null;
        } catch {}
      }

      const direto = atual.nativeFlowResponseMessage?.paramsJson;
      if (direto) {
        try {
          const dados = JSON.parse(direto);
          return dados.id || dados.row_id || dados.selectedId || null;
        } catch {}
      }

      // Botões antigos
      if (atual.buttonsResponseMessage?.selectedButtonId) return atual.buttonsResponseMessage.selectedButtonId;

      // Formato usado por algumas versões do WhatsApp pra quick_reply
      if (atual.templateButtonReplyMessage?.selectedId) return atual.templateButtonReplyMessage.selectedId;

      // Listas
      const lista = atual.listResponseMessage?.singleSelectReply?.selectedRowId;
      if (lista) return lista;

      for (const nome of wrappers) {
        const interno = atual[nome]?.message;
        if (interno && typeof interno === "object") fila.push(interno);
      }
    }
  } catch (erro) {
    console.error("⚠️ Não consegui ler o clique do botão:", erro?.message || erro);
  }
  return null;
}

// ────────────────────────────────────────────────────────────────
// 🎯 O QUE FAZER QUANDO ALGUÉM TOCA EM UM BOTÃO DO MENU
//
// Retorna:
//   false             → esse id não é do menu (o zarabot.js segue o fluxo dele)
//   true              → o menu já tratou (resposta enviada)
//   { comando: "…" }  → o zarabot.js deve executar esse comando como se a
//                       pessoa tivesse digitado (ex.: ".ping")
// ────────────────────────────────────────────────────────────────
async function tratarCliqueMenu(sock, msg, idBotao) {
  const from = msg.key.remoteJid;
  const id = String(idBotao || "");

  if (id.startsWith("cfg:")) {
    const op = id.slice(4);
    const opcao = CONFIG_OPCOES.find(o => o.id === op);
    if (!opcao) return true;

    if (opcao.instrucao) {
      const p = config.PREFIX;
      await sock.sendMessage(from, {
        text: `🖼️ Envie (ou *responda*) a mídia escrevendo *${p}configurar-bot ${opcao.instrucao}* na legenda/resposta.`,
      }, { quoted: msg });
      return true;
    }

    if (CONFIG_PENDENTE[op]) {
      setInteractivePending(msg, { command: `configurar-bot ${CONFIG_PENDENTE[op]}` });
      await sock.sendMessage(from, { text: opcao.pergunta }, { quoted: msg });
      return true;
    }

    if (Object.prototype.hasOwnProperty.call(CONFIG_ARGS, op)) {
      return { comando: `${config.PREFIX}configurar-bot${CONFIG_ARGS[op] ? " " + CONFIG_ARGS[op] : ""}` };
    }
    return true;
  }

  if (id.startsWith("cmd:")) {
    const cmd = id.slice(4).toLowerCase();

    // Só aceita comandos que estão nas listas do menu — um clique forjado
    // não consegue executar nada além do que o menu mostra.
    if (!TODOS_OS_COMANDOS.has(cmd)) return true;

    const instrucao = instrucaoMidia(cmd);
    if (instrucao) {
      await sock.sendMessage(from, { text: instrucao }, { quoted: msg });
      return true;
    }

    if (ENTRADA[cmd]) {
      setInteractivePending(msg, { command: cmd });
      await sock.sendMessage(from, { text: ENTRADA[cmd] }, { quoted: msg });
      return true;
    }

    return { comando: `${config.PREFIX}${cmd}` };
  }

  if (id === "dono_info") {
    return { comando: `${config.PREFIX}dono` };
  }

  if (id === "menu_home") {
    await sendMenuBotoes(sock, from, msg, { audio: false });
    return true;
  }

  if (id === "menu_texto") {
    const { menu } = require("./menu");
    await menu(sock, from);
    return true;
  }

  return false;
}

module.exports = {
  // usados pelo zarabot.js
  sendMenuBotoes,
  extrairIdBotaoClicado,
  tratarCliqueMenu,
  getInteractivePending,
  setInteractivePending,
  clearInteractivePending,
  // blocos reaproveitáveis
  enviarNativeFlow,
  enviarListaWhatsApp,
  botao,
  botaoUrl,
  botaoLista,
  linhaLista,
  obterLinkCanalConfig,
  linkFalarComCriador,
  CATEGORIAS,
  CONFIG_OPCOES,
};
