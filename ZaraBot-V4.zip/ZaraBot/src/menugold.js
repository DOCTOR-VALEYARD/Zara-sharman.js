const config = require("../config");
async function menugold(sock, msg) {
    const from = msg.key.remoteJid;
    const resposta = `
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』${config.BOT_NAME}『 ✦ 』
┅┄┅┄『 ✦ 』┄┅┄┅┄

  💰 MENU GOLD 💰

┅┄┅┄『 ✦ 』┄┅┄┅┄
  💸 ECONOMIA & MOEDAS
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』 ${config.PREFIX}saldo ➜ Ver saldo Gold
『 ✦ 』 ${config.PREFIX}roubar [@user] ➜ Roubar Gold
『 ✦ 』 ${config.PREFIX}loja ➜ Comprar itens
『 ✦ 』 ${config.PREFIX}duelo [@user] ➜ Apostar Gold
『 ✦ 』 ${config.PREFIX}resgatar ➜ Resgatar token
┅┄┅┄『 ✦ 』┄┅┄┅┄
  🏆 RANKING
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』 ${config.PREFIX}rank ➜ Ver ranking
『 ✦ 』 ${config.PREFIX}perfil ➜ Seu perfil
┅┄┅┄『 ✦ 』┄┅┄┅┄
  📊 CONVERSÃO
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』 1000 Gold = 1 Premium
┅┄┅┄『 ✦ 』┄┅┄┅┄`;
    await sock.sendMessage(from, { text: resposta }, { quoted: msg });
}
module.exports = { menugold };
