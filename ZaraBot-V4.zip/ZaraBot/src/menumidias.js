/* =================================================
   📂 MENU MÍDIAS — ÁUDIO • IMAGEM • VÍDEO
   📁 Arquivo: menumidias.js
   🤖 ${config.BOT_NAME} • ${config.OWNER_NAME}
   ================================================= */

const config = require("../config");

async function menumidias(sock, msg) {
    const from = msg.key.remoteJid;

    const texto = `┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』${config.BOT_NAME}『 ✦ 』
┅┄┅┄『 ✦ 』┄┅┄┅┄

  📂 MENU DE MÍDIAS 📂

┅┄┅┄『 ✦ 』┄┅┄┅┄
  🎵 ÁUDIO E MÚSICA
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』 ${config.PREFIX}play [nome/link] ➜ Baixa e envia em MP3
『 ✦ 』 ${config.PREFIX}casal ➜ Monta foto de casal criativa
┅┄┅┄『 ✦ 』┄┅┄┅┄
  🎨 IMAGEM, FIGURINHA E VÍDEO
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』 ${config.PREFIX}s / ${config.PREFIX}sticker ➜ Transforma em figurinha
『 ✦ 』 ${config.PREFIX}f / ${config.PREFIX}gif ➜ Converte mídia para GIF animado
『 ✦ 』 ${config.PREFIX}toimg ➜ Transforma figurinha em imagem normal
┅┄┅┄『 ✦ 』┄┅┄┅┄
  📜 HISTÓRICO E ARQUIVOS
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』 ${config.PREFIX}dvcl ➜ Salva figurinha na coleção do bot
『 ✦ 』 ${config.PREFIX}historico-dvcl ➜ Lista todas salvas anteriormente
┅┄┅┄『 ✦ 』┄┅┄┅┄
✨ ${config.BOT_NAME} — Criação e Conversão ✨`;

    await sock.sendMessage(from, { text: texto }, { quoted: msg });
}

module.exports = { menumidias };

