/* =================================================
   📊 ZARA BOT — RELATÓRIO DIÁRIO AUTOMÁTICO
   📁 Arquivo: relatorio.js
   👑 DOCTOR VALEYARD

   Antes não existia NENHUM agendamento — por isso o relatório
   de fim de dia nunca acontecia sozinho (só existia o ".resumo"
   manual, que alguém precisava digitar).

   Esse arquivo:
   - Guarda quantas mensagens (e quem participou) cada grupo teve no dia
   - Manda um relatório automático todo dia, no horário configurado, só
     pros grupos que ativaram com ".relatorio"
   - Se o bot cair e voltar, não manda relatório duplicado no mesmo dia
================================================= */

const fs = require("fs");
const path = require("path");
const config = require("../config");
const { getDB, saveDB } = require("./grupo");

// ⏰ Horário do relatório automático (24h). Mude aqui se quiser outro horário.
const HORA_RELATORIO = 23;
const MINUTO_RELATORIO = 59;

// 📈 Estatísticas do dia, em memória: { [grupoId]: { mensagens: n, participantes: Set } }
const statsDoDia = {};

function registrarMensagemRelatorio(grupoId, participanteId) {
    if (!statsDoDia[grupoId]) statsDoDia[grupoId] = { mensagens: 0, participantes: new Set() };
    statsDoDia[grupoId].mensagens++;
    if (participanteId) statsDoDia[grupoId].participantes.add(participanteId);
}

// 🗂️ Guarda a data do último relatório enviado, pra não duplicar se o bot reiniciar
const marcadorPath = path.join(__dirname, "relatorio-ultimo-envio.json");
function lerUltimoEnvio() {
    try {
        if (fs.existsSync(marcadorPath)) return JSON.parse(fs.readFileSync(marcadorPath, "utf8"));
    } catch {}
    return {};
}
function salvarUltimoEnvio(dataStr) {
    try { fs.writeFileSync(marcadorPath, JSON.stringify({ ultimoEnvio: dataStr }, null, 2), "utf8"); } catch {}
}

// ✅/❌ LIGA-DESLIGA por grupo — comando: .relatorio
async function toggleRelatorio(sock, msg) {
    const from = msg.key.remoteJid;
    if (!from.endsWith("@g.us")) {
        return sock.sendMessage(from, { text: "❌ Esse comando só funciona dentro de grupos!" }, { quoted: msg });
    }
    const db = getDB();
    if (!db[from]) db[from] = {};
    const novoEstado = !db[from].relatorioDiario;
    db[from].relatorioDiario = novoEstado;
    saveDB(db);

    const texto = novoEstado
        ? `✅ *RELATÓRIO DIÁRIO ATIVADO*\n\n📊 Todo dia, por volta das ${HORA_RELATORIO}:${String(MINUTO_RELATORIO).padStart(2,'0')}, esse grupo vai receber um resumo automático do dia.\n\n❀ ${config.BOT_NAME}`
        : `❌ *RELATÓRIO DIÁRIO DESATIVADO*\n\nEsse grupo não vai mais receber o resumo automático de fim de dia.\n\n❀ ${config.BOT_NAME}`;
    await sock.sendMessage(from, { text: texto }, { quoted: msg });
}

// 📊 Monta e manda o relatório de um grupo específico
async function enviarRelatorioGrupo(sock, grupoId) {
    const stats = statsDoDia[grupoId] || { mensagens: 0, participantes: new Set() };
    let nomeGrupo = "Grupo", totalMembros = "N/A";
    try {
        const meta = await sock.groupMetadata(grupoId);
        nomeGrupo = meta.subject;
        totalMembros = meta.participants.length;
    } catch (erro) {
        console.error(`⚠️ Não consegui buscar metadados pra relatório de ${grupoId}:`, erro?.message || erro);
    }

    const hoje = new Date().toLocaleDateString("pt-BR");
    const texto = `╭─「 📊 *RELATÓRIO DO DIA* 」
│
│ 📛 Grupo: ${nomeGrupo}
│ 📅 Data: ${hoje}
│ 👥 Membros atuais: ${totalMembros}
│ 💬 Mensagens hoje: ${stats.mensagens}
│ 🙋 Pessoas que falaram: ${stats.participantes.size}
│
╰───────────────────────────
🤖 ${config.BOT_NAME} • ${config.OWNER_NAME}`;

    try {
        await sock.sendMessage(grupoId, { text: texto });
    } catch (erro) {
        console.error(`❌ Falha ao enviar relatório diário pra ${grupoId}:`, erro?.message || erro);
    }
}

// 🚀 Manda o relatório pra todos os grupos que ativaram, e zera as estatísticas
async function enviarRelatorioDiario(sock) {
    const db = getDB();
    const grupos = Object.keys(db).filter(g => db[g]?.relatorioDiario);

    for (const grupoId of grupos) {
        await enviarRelatorioGrupo(sock, grupoId);
        await new Promise(r => setTimeout(r, 800)); // não manda tudo de uma vez
    }

    // zera as estatísticas do dia que terminou
    for (const grupoId of Object.keys(statsDoDia)) delete statsDoDia[grupoId];
}

// ⏰ AGENDADOR — checa a cada minuto se chegou a hora do relatório
function iniciarAgendadorDiario(sock) {
    const intervalId = setInterval(async () => {
        try {
            const agora = new Date();
            const hojeStr = agora.toLocaleDateString("pt-BR");

            if (
                agora.getHours() === HORA_RELATORIO &&
                agora.getMinutes() === MINUTO_RELATORIO &&
                lerUltimoEnvio().ultimoEnvio !== hojeStr
            ) {
                salvarUltimoEnvio(hojeStr); // marca ANTES de enviar, evita duplicar se demorar
                console.log("📊 Enviando relatório diário automático...");
                await enviarRelatorioDiario(sock);
            }
        } catch (erro) {
            console.error("❌ Erro no agendador de relatório diário:", erro);
        }
    }, 60 * 1000);

    console.log(`📊 Agendador de relatório diário ativo (todo dia às ${HORA_RELATORIO}:${String(MINUTO_RELATORIO).padStart(2,'0')}).`);
    return intervalId;
}

module.exports = { registrarMensagemRelatorio, toggleRelatorio, iniciarAgendadorDiario, enviarRelatorioDiario };
