// 🔗 Ponte de compatibilidade — o arquivo principal do bot agora é
// zarabot.js (Zara Bot). Este arquivo existe só pra quem tinha o costume
// de rodar "node dvcl.js" continuar funcionando sem precisar mudar nada.
require("./zarabot.js");
